<?php

$contents = file_get_contents('Testing.json');
$data = json_decode($contents, true);

$name = $_POST["name"];
$gold = $_POST["gold"];
$level = (int)$_POST["level"];
$pmaffin = $_POST["pmaffin"];
$stats = (int)$_POST["stats"];
$actval = $_POST["actval"];

//helmet
$HelmAffix1val = (int)$_POST["HelmAffix1val"];
$HelmAffix2val = (int)$_POST["HelmAffix2val"];
$HelmAffix3val = (int)$_POST["HelmAffix3val"];
$Ha1val = (int)$_POST["Ha1val"];
$Ha2val = (int)$_POST["Ha2val"];
$Ha3val = (int)$_POST["Ha3val"];
$Ha4val = (int)$_POST["Ha4val"];
$Ha5val = (int)$_POST["Ha5val"];
$Ha6val = (int)$_POST["Ha6val"];
$Ha7val = (int)$_POST["Ha7val"];
$Ha8val = (int)$_POST["Ha8val"];
$Ha9val = (int)$_POST["Ha9val"];
$Ha10val = (int)$_POST["Ha10val"];
$Ha11val1 = (int)$_POST["Ha11val1"];
$Ha11val2 = (int)$_POST["Ha11val2"];
$Ha12val1 = (int)$_POST["Ha12val1"];
$Ha12val2 = (int)$_POST["Ha12val2"];
$Ha13val1 = (int)$_POST["Ha13val1"];
$Ha13val2 = (int)$_POST["Ha13val2"];

$Hea1 = filter_input(INPUT_POST, 'HelmAtt1');
$exploded_valueh1 = explode('|', $Hea1);
$Hea11 = $exploded_valueh1[0];
$Hea12 = $exploded_valueh1[1];
$Hea13 = $exploded_valueh1[2];

$Hea2 = filter_input(INPUT_POST, 'HelmAtt2');
$exploded_valueh2 = explode('|', $Hea2);
$Hea21 = $exploded_valueh2[0];
$Hea22 = $exploded_valueh2[1];
$Hea23 = $exploded_valueh2[2];

$Hea3 = filter_input(INPUT_POST, 'HelmAtt3');
$exploded_valueh3 = explode('|', $Hea3);
$Hea31 = $exploded_valueh3[0];
$Hea32 = $exploded_valueh3[1];
$Hea33 = $exploded_valueh3[2];

$Hea4 = filter_input(INPUT_POST, 'HelmAtt4');
$exploded_valueh4 = explode('|', $Hea4);
$Hea41 = $exploded_valueh4[0];
$Hea42 = $exploded_valueh4[1];
$Hea43 = $exploded_valueh4[2];

$Hea5 = filter_input(INPUT_POST, 'HelmAtt5');
$exploded_valueh5 = explode('|', $Hea5);
$Hea51 = $exploded_valueh5[0];
$Hea52 = $exploded_valueh5[1];
$Hea53 = $exploded_valueh5[2];

$Hea6 = filter_input(INPUT_POST, 'HelmAtt6');
$exploded_valueh6 = explode('|', $Hea6);
$Hea61 = $exploded_valueh6[0];
$Hea62 = $exploded_valueh6[1];
$Hea63 = $exploded_valueh6[2];

$Hea7 = filter_input(INPUT_POST, 'HelmAtt7');
$exploded_valueh7 = explode('|', $Hea7);
$Hea71 = $exploded_valueh7[0];
$Hea72 = $exploded_valueh7[1];
$Hea73 = $exploded_valueh7[2];

$Hea8 = filter_input(INPUT_POST, 'HelmAtt8');
$exploded_valueh8 = explode('|', $Hea8);
$Hea81 = $exploded_valueh8[0];
$Hea82 = $exploded_valueh8[1];
$Hea83 = $exploded_valueh8[2];

$Hea9 = filter_input(INPUT_POST, 'HelmAtt9');
$exploded_valueh9 = explode('|', $Hea9);
$Hea91 = $exploded_valueh9[0];
$Hea92 = $exploded_valueh9[1];
$Hea93 = $exploded_valueh9[2];

$Hea10 = filter_input(INPUT_POST, 'HelmAtt10');
$exploded_valueh10 = explode('|', $Hea10);
$Hea101 = $exploded_valueh10[0];
$Hea102 = $exploded_valueh10[1];
$Hea103 = $exploded_valueh10[2];

$Hea11_1 = filter_input(INPUT_POST, 'HelmAtt11');
$exploded_valueh11 = explode('|', $Hea11_1);
$Hea111 = $exploded_valueh11[0];
$Hea112 = $exploded_valueh11[1];
$Hea113 = $exploded_valueh11[2];
$Hea114 = $exploded_valueh11[3];

$Hea12_1 = filter_input(INPUT_POST, 'HelmAtt12');
$exploded_valueh12 = explode('|', $Hea12_1);
$Hea121 = $exploded_valueh12[0];
$Hea122 = $exploded_valueh12[1];
$Hea123 = $exploded_valueh12[2];
$Hea124 = $exploded_valueh12[3];

$Hea13_1 = filter_input(INPUT_POST, 'HelmAtt13');
$exploded_valueh13 = explode('|', $Hea13_1);
$Hea131 = $exploded_valueh13[0];
$Hea132 = $exploded_valueh13[1];
$Hea133 = $exploded_valueh13[2];
$Hea134 = $exploded_valueh13[3];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Chest
$ChestAffix1val = (int)$_POST["ChestAffix1val"];
$ChestAffix2val = (int)$_POST["ChestAffix2val"];
$ChestAffix3val = (int)$_POST["ChestAffix3val"];
$Che1val = (int)$_POST["Che1val"];
$Che2val = (int)$_POST["Che2val"];
$Che3val = (int)$_POST["Che3val"];
$Che4val = (int)$_POST["Che4val"];
$Che5val = (int)$_POST["Che5val"];
$Che6val = (int)$_POST["Che6val"];
$Che7val = (int)$_POST["Che7val"];
$Che8val = (int)$_POST["Che8val"];
$Che9val = (int)$_POST["Che9val"];
$Che10val = (int)$_POST["Che10val"];
$Che11val1 = (int)$_POST["Che11val1"];
$Che11val2 = (int)$_POST["Che11val2"];
$Che12val1 = (int)$_POST["Che12val1"];
$Che12val2 = (int)$_POST["Che12val2"];
$Che13val1 = (int)$_POST["Che13val1"];
$Che13val2 = (int)$_POST["Che13val2"];

$Chest1 = filter_input(INPUT_POST, 'ChestAtt1');
$exploded_valuech1 = explode('|', $Chest1);
$Chest11 = $exploded_valuech1[0];
$Chest12 = $exploded_valuech1[1];
$Chest13 = $exploded_valuech1[2];

$Chest2 = filter_input(INPUT_POST, 'ChestAtt2');
$exploded_valuech2 = explode('|', $Chest2);
$Chest21 = $exploded_valuech2[0];
$Chest22 = $exploded_valuech2[1];
$Chest23 = $exploded_valuech2[2];

$Chest3 = filter_input(INPUT_POST, 'ChestAtt3');
$exploded_valuech3 = explode('|', $Chest3);
$Chest31 = $exploded_valuech3[0];
$Chest32 = $exploded_valuech3[1];
$Chest33 = $exploded_valuech3[2];

$Chest4 = filter_input(INPUT_POST, 'ChestAtt4');
$exploded_valuech4 = explode('|', $Chest4);
$Chest41 = $exploded_valuech4[0];
$Chest42 = $exploded_valuech4[1];
$Chest43 = $exploded_valuech4[2];

$Chest5 = filter_input(INPUT_POST, 'ChestAtt5');
$exploded_valuech5 = explode('|', $Chest5);
$Chest51 = $exploded_valuech5[0];
$Chest52 = $exploded_valuech5[1];
$Chest53 = $exploded_valuech5[2];

$Chest6 = filter_input(INPUT_POST, 'ChestAtt6');
$exploded_valuech6 = explode('|', $Chest6);
$Chest61 = $exploded_valuech6[0];
$Chest62 = $exploded_valuech6[1];
$Chest63 = $exploded_valuech6[2];

$Chest7 = filter_input(INPUT_POST, 'ChestAtt7');
$exploded_valuech7 = explode('|', $Chest7);
$Chest71 = $exploded_valuech7[0];
$Chest72 = $exploded_valuech7[1];
$Chest73 = $exploded_valuech7[2];

$Chest8 = filter_input(INPUT_POST, 'ChestAtt8');
$exploded_valuech8 = explode('|', $Chest8);
$Chest81 = $exploded_valuech8[0];
$Chest82 = $exploded_valuech8[1];
$Chest83 = $exploded_valuech8[2];

$Chest9 = filter_input(INPUT_POST, 'ChestAtt9');
$exploded_valuech9 = explode('|', $Chest9);
$Chest91 = $exploded_valuech9[0];
$Chest92 = $exploded_valuech9[1];
$Chest93 = $exploded_valuech9[2];

$Chest10 = filter_input(INPUT_POST, 'ChestAtt10');
$exploded_valuech10 = explode('|', $Chest10);
$Chest101 = $exploded_valuech10[0];
$Chest102 = $exploded_valuech10[1];
$Chest103 = $exploded_valuech10[2];

$Chest11_1 = filter_input(INPUT_POST, 'ChestAtt11');
$exploded_valuech11 = explode('|', $Chest11_1);
$Chest111 = $exploded_valuech11[0];
$Chest112 = $exploded_valuech11[1];
$Chest113 = $exploded_valuech11[2];
$Chest114 = $exploded_valuech11[3];

$Chest12_1 = filter_input(INPUT_POST, 'ChestAtt12');
$exploded_valuech12 = explode('|', $Chest12_1);
$Chest121 = $exploded_valuech12[0];
$Chest122 = $exploded_valuech12[1];
$Chest123 = $exploded_valuech12[2];
$Chest124 = $exploded_valuech12[3];

$Chest13_1 = filter_input(INPUT_POST, 'ChestAtt13');
$exploded_valuech13 = explode('|', $Chest13_1);
$Chest131 = $exploded_valuech13[0];
$Chest132 = $exploded_valuech13[1];
$Chest133 = $exploded_valuech13[2];
$Chest134 = $exploded_valuech13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Legs
$LegsAffix1val = (int)$_POST["LegsAffix1val"];
$LegsAffix2val = (int)$_POST["LegsAffix2val"];
$LegsAffix3val = (int)$_POST["LegsAffix3val"];
$Legs1val = (int)$_POST["Legs1val"];
$Legs2val = (int)$_POST["Legs2val"];
$Legs3val = (int)$_POST["Legs3val"];
$Legs4val = (int)$_POST["Legs4val"];
$Legs5val = (int)$_POST["Legs5val"];
$Legs6val = (int)$_POST["Legs6val"];
$Legs7val = (int)$_POST["Legs7val"];
$Legs8val = (int)$_POST["Legs8val"];
$Legs9val = (int)$_POST["Legs9val"];
$Legs10val = (int)$_POST["Legs10val"];
$Legs11val1 = (int)$_POST["Legs11val1"];
$Legs11val2 = (int)$_POST["Legs11val2"];
$Legs12val1 = (int)$_POST["Legs12val1"];
$Legs12val2 = (int)$_POST["Legs12val2"];
$Legs13val1 = (int)$_POST["Legs13val1"];
$Legs13val2 = (int)$_POST["Legs13val2"];

$Legs1 = filter_input(INPUT_POST, 'LegsAtt1');
$exploded_valueleg1 = explode('|', $Legs1);
$Legs11 = $exploded_valueleg1[0];
$Legs12 = $exploded_valueleg1[1];
$Legs13 = $exploded_valueleg1[2];

$Legs2 = filter_input(INPUT_POST, 'LegsAtt2');
$exploded_valueleg2 = explode('|', $Legs2);
$Legs21 = $exploded_valueleg2[0];
$Legs22 = $exploded_valueleg2[1];
$Legs23 = $exploded_valueleg2[2];

$Legs3 = filter_input(INPUT_POST, 'LegsAtt3');
$exploded_valueleg3 = explode('|', $Legs3);
$Legs31 = $exploded_valueleg3[0];
$Legs32 = $exploded_valueleg3[1];
$Legs33 = $exploded_valueleg3[2];

$Legs4 = filter_input(INPUT_POST, 'LegsAtt4');
$exploded_valueleg4 = explode('|', $Legs4);
$Legs41 = $exploded_valueleg4[0];
$Legs42 = $exploded_valueleg4[1];
$Legs43 = $exploded_valueleg4[2];

$Legs5 = filter_input(INPUT_POST, 'LegsAtt5');
$exploded_valueleg5 = explode('|', $Legs5);
$Legs51 = $exploded_valueleg5[0];
$Legs52 = $exploded_valueleg5[1];
$Legs53 = $exploded_valueleg5[2];

$Legs6 = filter_input(INPUT_POST, 'LegsAtt6');
$exploded_valueleg6 = explode('|', $Legs6);
$Legs61 = $exploded_valueleg6[0];
$Legs62 = $exploded_valueleg6[1];
$Legs63 = $exploded_valueleg6[2];

$Legs7 = filter_input(INPUT_POST, 'LegsAtt7');
$exploded_valueleg7 = explode('|', $Legs7);
$Legs71 = $exploded_valueleg7[0];
$Legs72 = $exploded_valueleg7[1];
$Legs73 = $exploded_valueleg7[2];

$Legs8 = filter_input(INPUT_POST, 'LegsAtt8');
$exploded_valueleg8 = explode('|', $Legs8);
$Legs81 = $exploded_valueleg8[0];
$Legs82 = $exploded_valueleg8[1];
$Legs83 = $exploded_valueleg8[2];

$Legs9 = filter_input(INPUT_POST, 'LegsAtt9');
$exploded_valueleg9 = explode('|', $Legs9);
$Legs91 = $exploded_valueleg9[0];
$Legs92 = $exploded_valueleg9[1];
$Legs93 = $exploded_valueleg9[2];

$Legs10 = filter_input(INPUT_POST, 'LegsAtt10');
$exploded_valueleg10 = explode('|', $Legs10);
$Legs101 = $exploded_valueleg10[0];
$Legs102 = $exploded_valueleg10[1];
$Legs103 = $exploded_valueleg10[2];

$Legs11_1 = filter_input(INPUT_POST, 'LegsAtt11');
$exploded_valueleg11 = explode('|', $Legs11_1);
$Legs111 = $exploded_valueleg11[0];
$Legs112 = $exploded_valueleg11[1];
$Legs113 = $exploded_valueleg11[2];
$Legs114 = $exploded_valueleg11[3];

$Legs12_1 = filter_input(INPUT_POST, 'LegsAtt12');
$exploded_valueleg12 = explode('|', $Legs12_1);
$Legs121 = $exploded_valueleg12[0];
$Legs122 = $exploded_valueleg12[1];
$Legs123 = $exploded_valueleg12[2];
$Legs124 = $exploded_valueleg12[3];

$Legs13_1 = filter_input(INPUT_POST, 'LegsAtt13');
$exploded_valueleg13 = explode('|', $Legs13_1);
$Legs131 = $exploded_valueleg13[0];
$Legs132 = $exploded_valueleg13[1];
$Legs133 = $exploded_valueleg13[2];
$Legs134 = $exploded_valueleg13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Boots
$BootsAffix1val = (int)$_POST["BootsAffix1val"];
$BootsAffix2val = (int)$_POST["BootsAffix2val"];
$BootsAffix3val = (int)$_POST["BootsAffix3val"];
$Boots1val = (int)$_POST["Boots1val"];
$Boots2val = (int)$_POST["Boots2val"];
$Boots3val = (int)$_POST["Boots3val"];
$Boots4val = (int)$_POST["Boots4val"];
$Boots5val = (int)$_POST["Boots5val"];
$Boots6val = (int)$_POST["Boots6val"];
$Boots7val = (int)$_POST["Boots7val"];
$Boots8val = (int)$_POST["Boots8val"];
$Boots9val = (int)$_POST["Boots9val"];
$Boots10val = (int)$_POST["Boots10val"];
$Boots11val1 = (int)$_POST["Boots11val1"];
$Boots11val2 = (int)$_POST["Boots11val2"];
$Boots12val1 = (int)$_POST["Boots12val1"];
$Boots12val2 = (int)$_POST["Boots12val2"];
$Boots13val1 = (int)$_POST["Boots13val1"];
$Boots13val2 = (int)$_POST["Boots13val2"];

$Boots1 = filter_input(INPUT_POST, 'BootsAtt1');
$exploded_valueboot1 = explode('|', $Boots1);
$Boots11 = $exploded_valueboot1[0];
$Boots12 = $exploded_valueboot1[1];
$Boots13 = $exploded_valueboot1[2];

$Boots2 = filter_input(INPUT_POST, 'BootsAtt2');
$exploded_valueboot2 = explode('|', $Boots2);
$Boots21 = $exploded_valueboot2[0];
$Boots22 = $exploded_valueboot2[1];
$Boots23 = $exploded_valueboot2[2];

$Boots3 = filter_input(INPUT_POST, 'BootsAtt3');
$exploded_valueboot3 = explode('|', $Boots3);
$Boots31 = $exploded_valueboot3[0];
$Boots32 = $exploded_valueboot3[1];
$Boots33 = $exploded_valueboot3[2];

$Boots4 = filter_input(INPUT_POST, 'BootsAtt4');
$exploded_valueboot4 = explode('|', $Boots4);
$Boots41 = $exploded_valueboot4[0];
$Boots42 = $exploded_valueboot4[1];
$Boots43 = $exploded_valueboot4[2];

$Boots5 = filter_input(INPUT_POST, 'BootsAtt5');
$exploded_valueboot5 = explode('|', $Boots5);
$Boots51 = $exploded_valueboot5[0];
$Boots52 = $exploded_valueboot5[1];
$Boots53 = $exploded_valueboot5[2];

$Boots6 = filter_input(INPUT_POST, 'BootsAtt6');
$exploded_valueboot6 = explode('|', $Boots6);
$Boots61 = $exploded_valueboot6[0];
$Boots62 = $exploded_valueboot6[1];
$Boots63 = $exploded_valueboot6[2];

$Boots7 = filter_input(INPUT_POST, 'BootsAtt7');
$exploded_valueboot7 = explode('|', $Boots7);
$Boots71 = $exploded_valueboot7[0];
$Boots72 = $exploded_valueboot7[1];
$Boots73 = $exploded_valueboot7[2];

$Boots8 = filter_input(INPUT_POST, 'BootsAtt8');
$exploded_valueboot8 = explode('|', $Boots8);
$Boots81 = $exploded_valueboot8[0];
$Boots82 = $exploded_valueboot8[1];
$Boots83 = $exploded_valueboot8[2];

$Boots9 = filter_input(INPUT_POST, 'BootsAtt9');
$exploded_valueboot9 = explode('|', $Boots9);
$Boots91 = $exploded_valueboot9[0];
$Boots92 = $exploded_valueboot9[1];
$Boots93 = $exploded_valueboot9[2];

$Boots10 = filter_input(INPUT_POST, 'BootsAtt10');
$exploded_valueboot10 = explode('|', $Boots10);
$Boots101 = $exploded_valueboot10[0];
$Boots102 = $exploded_valueboot10[1];
$Boots103 = $exploded_valueboot10[2];

$Boots11_1 = filter_input(INPUT_POST, 'BootsAtt11');
$exploded_valueboot11 = explode('|', $Boots11_1);
$Boots111 = $exploded_valueboot11[0];
$Boots112 = $exploded_valueboot11[1];
$Boots113 = $exploded_valueboot11[2];
$Boots114 = $exploded_valueboot11[3];

$Boots12_1 = filter_input(INPUT_POST, 'BootsAtt12');
$exploded_valueboot12 = explode('|', $Boots12_1);
$Boots121 = $exploded_valueboot12[0];
$Boots122 = $exploded_valueboot12[1];
$Boots123 = $exploded_valueboot12[2];
$Boots124 = $exploded_valueboot12[3];

$Boots13_1 = filter_input(INPUT_POST, 'BootsAtt13');
$exploded_valueboot13 = explode('|', $Boots13_1);
$Boots131 = $exploded_valueboot13[0];
$Boots132 = $exploded_valueboot13[1];
$Boots133 = $exploded_valueboot13[2];
$Boots134 = $exploded_valueboot13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Left Shoulder
$Shoulder1Affix1val = (int)$_POST["Shoulder1Affix1val"];
$Shoulder1Affix2val = (int)$_POST["Shoulder1Affix2val"];
$Shoulder1Affix3val = (int)$_POST["Shoulder1Affix3val"];
$Shoulder11val = (int)$_POST["Shoulder11val"];
$Shoulder12val = (int)$_POST["Shoulder12val"];
$Shoulder13val = (int)$_POST["Shoulder13val"];
$Shoulder14val = (int)$_POST["Shoulder14val"];
$Shoulder15val = (int)$_POST["Shoulder15val"];
$Shoulder16val = (int)$_POST["Shoulder16val"];
$Shoulder17val = (int)$_POST["Shoulder17val"];
$Shoulder18val = (int)$_POST["Shoulder18val"];
$Shoulder19val = (int)$_POST["Shoulder19val"];
$Shoulder110val = (int)$_POST["Shoulder110val"];
$Shoulder111val1 = (int)$_POST["Shoulder111val1"];
$Shoulder111val2 = (int)$_POST["Shoulder111val2"];
$Shoulder112val1 = (int)$_POST["Shoulder112val1"];
$Shoulder112val2 = (int)$_POST["Shoulder112val2"];
$Shoulder113val1 = (int)$_POST["Shoulder113val1"];
$Shoulder113val2 = (int)$_POST["Shoulder113val2"];

$Shoulder11 = filter_input(INPUT_POST, 'Shoulder1Att1');
$exploded_valueshoulder1 = explode('|', $Shoulder11);
$Shoulder111 = $exploded_valueshoulder1[0];
$Shoulder112 = $exploded_valueshoulder1[1];
$Shoulder113 = $exploded_valueshoulder1[2];

$Shoulder12 = filter_input(INPUT_POST, 'Shoulder1Att2');
$exploded_valueshoulder2 = explode('|', $Shoulder12);
$Shoulder121 = $exploded_valueshoulder2[0];
$Shoulder122 = $exploded_valueshoulder2[1];
$Shoulder123 = $exploded_valueshoulder2[2];

$Shoulder13 = filter_input(INPUT_POST, 'Shoulder1Att3');
$exploded_valueshoulder3 = explode('|', $Shoulder13);
$Shoulder131 = $exploded_valueshoulder3[0];
$Shoulder132 = $exploded_valueshoulder3[1];
$Shoulder133 = $exploded_valueshoulder3[2];

$Shoulder14 = filter_input(INPUT_POST, 'Shoulder1Att4');
$exploded_valueshoulder4 = explode('|', $Shoulder14);
$Shoulder141 = $exploded_valueshoulder4[0];
$Shoulder142 = $exploded_valueshoulder4[1];
$Shoulder143 = $exploded_valueshoulder4[2];

$Shoulder15 = filter_input(INPUT_POST, 'Shoulder1Att5');
$exploded_valueshoulder5 = explode('|', $Shoulder15);
$Shoulder151 = $exploded_valueshoulder5[0];
$Shoulder152 = $exploded_valueshoulder5[1];
$Shoulder153 = $exploded_valueshoulder5[2];

$Shoulder16 = filter_input(INPUT_POST, 'Shoulder1Att6');
$exploded_valueshoulder6 = explode('|', $Shoulder16);
$Shoulder161 = $exploded_valueshoulder6[0];
$Shoulder162 = $exploded_valueshoulder6[1];
$Shoulder163 = $exploded_valueshoulder6[2];

$Shoulder17 = filter_input(INPUT_POST, 'Shoulder1Att7');
$exploded_valueshoulder7 = explode('|', $Shoulder17);
$Shoulder171 = $exploded_valueshoulder7[0];
$Shoulder172 = $exploded_valueshoulder7[1];
$Shoulder173 = $exploded_valueshoulder7[2];

$Shoulder18 = filter_input(INPUT_POST, 'Shoulder1Att8');
$exploded_valueshoulder8 = explode('|', $Shoulder18);
$Shoulder181 = $exploded_valueshoulder8[0];
$Shoulder182 = $exploded_valueshoulder8[1];
$Shoulder183 = $exploded_valueshoulder8[2];

$Shoulder19 = filter_input(INPUT_POST, 'Shoulder1Att9');
$exploded_valueshoulder9 = explode('|', $Shoulder19);
$Shoulder191 = $exploded_valueshoulder9[0];
$Shoulder192 = $exploded_valueshoulder9[1];
$Shoulder193 = $exploded_valueshoulder9[2];

$Shoulder110 = filter_input(INPUT_POST, 'Shoulder1Att10');
$exploded_valueshoulder10 = explode('|', $Shoulder110);
$Shoulder1101 = $exploded_valueshoulder10[0];
$Shoulder1102 = $exploded_valueshoulder10[1];
$Shoulder1103 = $exploded_valueshoulder10[2];

$Shoulder111_1 = filter_input(INPUT_POST, 'Shoulder1Att11');
$exploded_valueshoulder11 = explode('|', $Shoulder111_1);
$Shoulder1111 = $exploded_valueshoulder11[0];
$Shoulder1112 = $exploded_valueshoulder11[1];
$Shoulder1113 = $exploded_valueshoulder11[2];
$Shoulder1114 = $exploded_valueshoulder11[3];

$Shoulder112_1 = filter_input(INPUT_POST, 'Shoulder1Att12');
$exploded_valueshoulder12 = explode('|', $Shoulder112_1);
$Shoulder1121 = $exploded_valueshoulder12[0];
$Shoulder1122 = $exploded_valueshoulder12[1];
$Shoulder1123 = $exploded_valueshoulder12[2];
$Shoulder1124 = $exploded_valueshoulder12[3];

$Shoulder113_1 = filter_input(INPUT_POST, 'Shoulder1Att13');
$exploded_valueshoulder13 = explode('|', $Shoulder113_1);
$Shoulder1131 = $exploded_valueshoulder13[0];
$Shoulder1132 = $exploded_valueshoulder13[1];
$Shoulder1133 = $exploded_valueshoulder13[2];
$Shoulder1134 = $exploded_valueshoulder13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Right Shoulder
$Shoulder2Affix1val = (int)$_POST["Shoulder2Affix1val"];
$Shoulder2Affix2val = (int)$_POST["Shoulder2Affix2val"];
$Shoulder2Affix3val = (int)$_POST["Shoulder2Affix3val"];
$Shoulder21val = (int)$_POST["Shoulder21val"];
$Shoulder22val = (int)$_POST["Shoulder22val"];
$Shoulder23val = (int)$_POST["Shoulder23val"];
$Shoulder24val = (int)$_POST["Shoulder24val"];
$Shoulder25val = (int)$_POST["Shoulder25val"];
$Shoulder26val = (int)$_POST["Shoulder26val"];
$Shoulder27val = (int)$_POST["Shoulder27val"];
$Shoulder28val = (int)$_POST["Shoulder28val"];
$Shoulder29val = (int)$_POST["Shoulder29val"];
$Shoulder210val = (int)$_POST["Shoulder210val"];
$Shoulder211val1 = (int)$_POST["Shoulder211val1"];
$Shoulder211val2 = (int)$_POST["Shoulder211val2"];
$Shoulder212val1 = (int)$_POST["Shoulder212val1"];
$Shoulder212val2 = (int)$_POST["Shoulder212val2"];
$Shoulder213val1 = (int)$_POST["Shoulder213val1"];
$Shoulder213val2 = (int)$_POST["Shoulder213val2"];

$Shoulder21 = filter_input(INPUT_POST, 'Shoulder2Att1');
$exploded_valueshoulderr1 = explode('|', $Shoulder21);
$Shoulder211 = $exploded_valueshoulderr1[0];
$Shoulder212 = $exploded_valueshoulderr1[1];
$Shoulder213 = $exploded_valueshoulderr1[2];

$Shoulder22 = filter_input(INPUT_POST, 'Shoulder2Att2');
$exploded_valueshoulderr2 = explode('|', $Shoulder22);
$Shoulder221 = $exploded_valueshoulderr2[0];
$Shoulder222 = $exploded_valueshoulderr2[1];
$Shoulder223 = $exploded_valueshoulderr2[2];

$Shoulder23 = filter_input(INPUT_POST, 'Shoulder2Att3');
$exploded_valueshoulderr3 = explode('|', $Shoulder23);
$Shoulder231 = $exploded_valueshoulderr3[0];
$Shoulder232 = $exploded_valueshoulderr3[1];
$Shoulder233 = $exploded_valueshoulderr3[2];

$Shoulder24 = filter_input(INPUT_POST, 'Shoulder2Att4');
$exploded_valueshoulderr4 = explode('|', $Shoulder24);
$Shoulder241 = $exploded_valueshoulderr4[0];
$Shoulder242 = $exploded_valueshoulderr4[1];
$Shoulder243 = $exploded_valueshoulderr4[2];

$Shoulder25 = filter_input(INPUT_POST, 'Shoulder2Att5');
$exploded_valueshoulderr5 = explode('|', $Shoulder25);
$Shoulder251 = $exploded_valueshoulderr5[0];
$Shoulder252 = $exploded_valueshoulderr5[1];
$Shoulder253 = $exploded_valueshoulderr5[2];

$Shoulder26 = filter_input(INPUT_POST, 'Shoulder2Att6');
$exploded_valueshoulderr6 = explode('|', $Shoulder26);
$Shoulder261 = $exploded_valueshoulderr6[0];
$Shoulder262 = $exploded_valueshoulderr6[1];
$Shoulder263 = $exploded_valueshoulderr6[2];

$Shoulder27 = filter_input(INPUT_POST, 'Shoulder2Att7');
$exploded_valueshoulderr7 = explode('|', $Shoulder27);
$Shoulder271 = $exploded_valueshoulderr7[0];
$Shoulder272 = $exploded_valueshoulderr7[1];
$Shoulder273 = $exploded_valueshoulderr7[2];

$Shoulder28 = filter_input(INPUT_POST, 'Shoulder2Att8');
$exploded_valueshoulderr8 = explode('|', $Shoulder28);
$Shoulder281 = $exploded_valueshoulderr8[0];
$Shoulder282 = $exploded_valueshoulderr8[1];
$Shoulder283 = $exploded_valueshoulderr8[2];

$Shoulder29 = filter_input(INPUT_POST, 'Shoulder2Att9');
$exploded_valueshoulderr9 = explode('|', $Shoulder29);
$Shoulder291 = $exploded_valueshoulderr9[0];
$Shoulder292 = $exploded_valueshoulderr9[1];
$Shoulder293 = $exploded_valueshoulderr9[2];

$Shoulder210 = filter_input(INPUT_POST, 'Shoulder2Att10');
$exploded_valueshoulderr10 = explode('|', $Shoulder210);
$Shoulder2101 = $exploded_valueshoulderr10[0];
$Shoulder2102 = $exploded_valueshoulderr10[1];
$Shoulder2103 = $exploded_valueshoulderr10[2];

$Shoulder211_1 = filter_input(INPUT_POST, 'Shoulder2Att11');
$exploded_valueshoulderr11 = explode('|', $Shoulder211_1);
$Shoulder2111 = $exploded_valueshoulderr11[0];
$Shoulder2112 = $exploded_valueshoulderr11[1];
$Shoulder2113 = $exploded_valueshoulderr11[2];
$Shoulder2114 = $exploded_valueshoulderr11[3];

$Shoulder212_1 = filter_input(INPUT_POST, 'Shoulder2Att12');
$exploded_valueshoulderr12 = explode('|', $Shoulder212_1);
$Shoulder2121 = $exploded_valueshoulderr12[0];
$Shoulder2122 = $exploded_valueshoulderr12[1];
$Shoulder2123 = $exploded_valueshoulderr12[2];
$Shoulder2124 = $exploded_valueshoulderr12[3];

$Shoulder213_1 = filter_input(INPUT_POST, 'Shoulder2Att13');
$exploded_valueshoulderr13 = explode('|', $Shoulder213_1);
$Shoulder2131 = $exploded_valueshoulderr13[0];
$Shoulder2132 = $exploded_valueshoulderr13[1];
$Shoulder2133 = $exploded_valueshoulderr13[2];
$Shoulder2134 = $exploded_valueshoulderr13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Left Glove
$Glove1Affix1val = (int)$_POST["Glove1Affix1val"];
$Glove1Affix2val = (int)$_POST["Glove1Affix2val"];
$Glove1Affix3val = (int)$_POST["Glove1Affix3val"];
$Glove11val = (int)$_POST["Glove11val"];
$Glove12val = (int)$_POST["Glove12val"];
$Glove13val = (int)$_POST["Glove13val"];
$Glove14val = (int)$_POST["Glove14val"];
$Glove15val = (int)$_POST["Glove15val"];
$Glove16val = (int)$_POST["Glove16val"];
$Glove17val = (int)$_POST["Glove17val"];
$Glove18val = (int)$_POST["Glove18val"];
$Glove19val = (int)$_POST["Glove19val"];
$Glove110val = (int)$_POST["Glove110val"];
$Glove111val1 = (int)$_POST["Glove111val1"];
$Glove111val2 = (int)$_POST["Glove111val2"];
$Glove112val1 = (int)$_POST["Glove112val1"];
$Glove112val2 = (int)$_POST["Glove112val2"];
$Glove113val1 = (int)$_POST["Glove113val1"];
$Glove113val2 = (int)$_POST["Glove113val2"];

$Glove11 = filter_input(INPUT_POST, 'Glove1Att1');
$exploded_valueglove11 = explode('|', $Glove11);
$Glove111 = $exploded_valueglove11[0];
$Glove112 = $exploded_valueglove11[1];
$Glove113 = $exploded_valueglove11[2];

$Glove12 = filter_input(INPUT_POST, 'Glove1Att2');
$exploded_valueglove12 = explode('|', $Glove12);
$Glove121 = $exploded_valueglove12[0];
$Glove122 = $exploded_valueglove12[1];
$Glove123 = $exploded_valueglove12[2];

$Glove13 = filter_input(INPUT_POST, 'Glove1Att3');
$exploded_valueglove13 = explode('|', $Glove13);
$Glove131 = $exploded_valueglove13[0];
$Glove132 = $exploded_valueglove13[1];
$Glove133 = $exploded_valueglove13[2];

$Glove14 = filter_input(INPUT_POST, 'Glove1Att4');
$exploded_valueglove14 = explode('|', $Glove14);
$Glove141 = $exploded_valueglove14[0];
$Glove142 = $exploded_valueglove14[1];
$Glove143 = $exploded_valueglove14[2];

$Glove15 = filter_input(INPUT_POST, 'Glove1Att5');
$exploded_valueglove15 = explode('|', $Glove15);
$Glove151 = $exploded_valueglove15[0];
$Glove152 = $exploded_valueglove15[1];
$Glove153 = $exploded_valueglove15[2];

$Glove16 = filter_input(INPUT_POST, 'Glove1Att6');
$exploded_valueglove16 = explode('|', $Glove16);
$Glove161 = $exploded_valueglove16[0];
$Glove162 = $exploded_valueglove16[1];
$Glove163 = $exploded_valueglove16[2];

$Glove17 = filter_input(INPUT_POST, 'Glove1Att7');
$exploded_valueglove17 = explode('|', $Glove17);
$Glove171 = $exploded_valueglove17[0];
$Glove172 = $exploded_valueglove17[1];
$Glove173 = $exploded_valueglove17[2];

$Glove18 = filter_input(INPUT_POST, 'Glove1Att8');
$exploded_valueglove18 = explode('|', $Glove18);
$Glove181 = $exploded_valueglove18[0];
$Glove182 = $exploded_valueglove18[1];
$Glove183 = $exploded_valueglove18[2];

$Glove19 = filter_input(INPUT_POST, 'Glove1Att9');
$exploded_valueglove19 = explode('|', $Glove19);
$Glove191 = $exploded_valueglove19[0];
$Glove192 = $exploded_valueglove19[1];
$Glove193 = $exploded_valueglove19[2];

$Glove110 = filter_input(INPUT_POST, 'Glove1Att10');
$exploded_valueglove110 = explode('|', $Glove110);
$Glove1101 = $exploded_valueglove110[0];
$Glove1102 = $exploded_valueglove110[1];
$Glove1103 = $exploded_valueglove110[2];

$Glove111_1 = filter_input(INPUT_POST, 'Glove1Att11');
$exploded_valueglove111 = explode('|', $Glove111_1);
$Glove1111 = $exploded_valueglove111[0];
$Glove1112 = $exploded_valueglove111[1];
$Glove1113 = $exploded_valueglove111[2];
$Glove1114 = $exploded_valueglove111[3];

$Glove112_1 = filter_input(INPUT_POST, 'Glove1Att12');
$exploded_valueglove112 = explode('|', $Glove112_1);
$Glove1121 = $exploded_valueglove112[0];
$Glove1122 = $exploded_valueglove112[1];
$Glove1123 = $exploded_valueglove112[2];
$Glove1124 = $exploded_valueglove112[3];

$Glove113_1 = filter_input(INPUT_POST, 'Glove1Att13');
$exploded_valueglove113 = explode('|', $Glove113_1);
$Glove1131 = $exploded_valueglove113[0];
$Glove1132 = $exploded_valueglove113[1];
$Glove1133 = $exploded_valueglove113[2];
$Glove1134 = $exploded_valueglove113[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Right Glove
$Glove2Affix1val = (int)$_POST["Glove2Affix1val"];
$Glove2Affix2val = (int)$_POST["Glove2Affix2val"];
$Glove2Affix3val = (int)$_POST["Glove2Affix3val"];
$Glove21val = (int)$_POST["Glove21val"];
$Glove22val = (int)$_POST["Glove22val"];
$Glove23val = (int)$_POST["Glove23val"];
$Glove24val = (int)$_POST["Glove24val"];
$Glove25val = (int)$_POST["Glove25val"];
$Glove26val = (int)$_POST["Glove26val"];
$Glove27val = (int)$_POST["Glove27val"];
$Glove28val = (int)$_POST["Glove28val"];
$Glove29val = (int)$_POST["Glove29val"];
$Glove210val = (int)$_POST["Glove210val"];
$Glove211val1 = (int)$_POST["Glove211val1"];
$Glove211val2 = (int)$_POST["Glove211val2"];
$Glove212val1 = (int)$_POST["Glove212val1"];
$Glove212val2 = (int)$_POST["Glove212val2"];
$Glove213val1 = (int)$_POST["Glove213val1"];
$Glove213val2 = (int)$_POST["Glove213val2"];

$Glove21 = filter_input(INPUT_POST, 'Glove2Att1');
$exploded_valueglover1 = explode('|', $Glove21);
$Glove211 = $exploded_valueglover1[0];
$Glove212 = $exploded_valueglover1[1];
$Glove213 = $exploded_valueglover1[2];

$Glove22 = filter_input(INPUT_POST, 'Glove2Att2');
$exploded_valueglover2 = explode('|', $Glove22);
$Glove221 = $exploded_valueglover2[0];
$Glove222 = $exploded_valueglover2[1];
$Glove223 = $exploded_valueglover2[2];

$Glove23 = filter_input(INPUT_POST, 'Glove2Att3');
$exploded_valueglover3 = explode('|', $Glove23);
$Glove231 = $exploded_valueglover3[0];
$Glove232 = $exploded_valueglover3[1];
$Glove233 = $exploded_valueglover3[2];

$Glove24 = filter_input(INPUT_POST, 'Glove2Att4');
$exploded_valueglover4 = explode('|', $Glove24);
$Glove241 = $exploded_valueglover4[0];
$Glove242 = $exploded_valueglover4[1];
$Glove243 = $exploded_valueglover4[2];

$Glove25 = filter_input(INPUT_POST, 'Glove2Att5');
$exploded_valueglover5 = explode('|', $Glove25);
$Glove251 = $exploded_valueglover5[0];
$Glove252 = $exploded_valueglover5[1];
$Glove253 = $exploded_valueglover5[2];

$Glove26 = filter_input(INPUT_POST, 'Glove2Att6');
$exploded_valueglover6 = explode('|', $Glove26);
$Glove261 = $exploded_valueglover6[0];
$Glove262 = $exploded_valueglover6[1];
$Glove263 = $exploded_valueglover6[2];

$Glove27 = filter_input(INPUT_POST, 'Glove2Att7');
$exploded_valueglover7 = explode('|', $Glove27);
$Glove271 = $exploded_valueglover7[0];
$Glove272 = $exploded_valueglover7[1];
$Glove273 = $exploded_valueglover7[2];

$Glove28 = filter_input(INPUT_POST, 'Glove2Att8');
$exploded_valueglover8 = explode('|', $Glove28);
$Glove281 = $exploded_valueglover8[0];
$Glove282 = $exploded_valueglover8[1];
$Glove283 = $exploded_valueglover8[2];

$Glove29 = filter_input(INPUT_POST, 'Glove2Att9');
$exploded_valueglover9 = explode('|', $Glove29);
$Glove291 = $exploded_valueglover9[0];
$Glove292 = $exploded_valueglover9[1];
$Glove293 = $exploded_valueglover9[2];

$Glove210 = filter_input(INPUT_POST, 'Glove2Att10');
$exploded_valueglover10 = explode('|', $Glove210);
$Glove2101 = $exploded_valueglover10[0];
$Glove2102 = $exploded_valueglover10[1];
$Glove2103 = $exploded_valueglover10[2];

$Glove211_1 = filter_input(INPUT_POST, 'Glove2Att11');
$exploded_valueglover11 = explode('|', $Glove211_1);
$Glove2111 = $exploded_valueglover11[0];
$Glove2112 = $exploded_valueglover11[1];
$Glove2113 = $exploded_valueglover11[2];
$Glove2114 = $exploded_valueglover11[3];

$Glove212_1 = filter_input(INPUT_POST, 'Glove2Att12');
$exploded_valueglover12 = explode('|', $Glove212_1);
$Glove2121 = $exploded_valueglover12[0];
$Glove2122 = $exploded_valueglover12[1];
$Glove2123 = $exploded_valueglover12[2];
$Glove2124 = $exploded_valueglover12[3];

$Glove213_1 = filter_input(INPUT_POST, 'Glove2Att13');
$exploded_valueglover13 = explode('|', $Glove213_1);
$Glove2131 = $exploded_valueglover13[0];
$Glove2132 = $exploded_valueglover13[1];
$Glove2133 = $exploded_valueglover13[2];
$Glove2134 = $exploded_valueglover13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Ring1
$Ring11val = (int)$_POST["Ring11val"];
$Ring12val = (int)$_POST["Ring12val"];
$Ring13val = (int)$_POST["Ring13val"];
$Ring14val = (int)$_POST["Ring14val"];
$Ring15val = (int)$_POST["Ring15val"];
$Ring16val = (int)$_POST["Ring16val"];
$Ring17val = (int)$_POST["Ring17val"];
$Ring18val = (int)$_POST["Ring18val"];
$Ring19val = (int)$_POST["Ring19val"];
$Ring110val = (int)$_POST["Ring110val"];
$Ring111val1 = (int)$_POST["Ring111val1"];
$Ring111val2 = (int)$_POST["Ring111val2"];
$Ring112val1 = (int)$_POST["Ring112val1"];
$Ring112val2 = (int)$_POST["Ring112val2"];
$Ring113val1 = (int)$_POST["Ring113val1"];
$Ring113val2 = (int)$_POST["Ring113val2"];

$Ring11 = filter_input(INPUT_POST, 'Ring1Att1');
$exploded_valuering11 = explode('|', $Ring11);
$Ring111 = $exploded_valuering11[0];
$Ring112 = $exploded_valuering11[1];
$Ring113 = $exploded_valuering11[2];

$Ring12 = filter_input(INPUT_POST, 'Ring1Att2');
$exploded_valuering12 = explode('|', $Ring12);
$Ring121 = $exploded_valuering12[0];
$Ring122 = $exploded_valuering12[1];
$Ring123 = $exploded_valuering12[2];

$Ring13 = filter_input(INPUT_POST, 'Ring1Att3');
$exploded_valuering13 = explode('|', $Ring13);
$Ring131 = $exploded_valuering13[0];
$Ring132 = $exploded_valuering13[1];
$Ring133 = $exploded_valuering13[2];

$Ring14 = filter_input(INPUT_POST, 'Ring1Att4');
$exploded_valuering14 = explode('|', $Ring14);
$Ring141 = $exploded_valuering14[0];
$Ring142 = $exploded_valuering14[1];
$Ring143 = $exploded_valuering14[2];

$Ring15 = filter_input(INPUT_POST, 'Ring1Att5');
$exploded_valuering15 = explode('|', $Ring15);
$Ring151 = $exploded_valuering15[0];
$Ring152 = $exploded_valuering15[1];
$Ring153 = $exploded_valuering15[2];

$Ring16 = filter_input(INPUT_POST, 'Ring1Att6');
$exploded_valuering16 = explode('|', $Ring16);
$Ring161 = $exploded_valuering16[0];
$Ring162 = $exploded_valuering16[1];
$Ring163 = $exploded_valuering16[2];

$Ring17 = filter_input(INPUT_POST, 'Ring1Att7');
$exploded_valuering17 = explode('|', $Ring17);
$Ring171 = $exploded_valuering17[0];
$Ring172 = $exploded_valuering17[1];
$Ring173 = $exploded_valuering17[2];

$Ring18 = filter_input(INPUT_POST, 'Ring1Att8');
$exploded_valuering18 = explode('|', $Ring18);
$Ring181 = $exploded_valuering18[0];
$Ring182 = $exploded_valuering18[1];
$Ring183 = $exploded_valuering18[2];

$Ring19 = filter_input(INPUT_POST, 'Ring1Att9');
$exploded_valuering19 = explode('|', $Ring19);
$Ring191 = $exploded_valuering19[0];
$Ring192 = $exploded_valuering19[1];
$Ring193 = $exploded_valuering19[2];

$Ring110 = filter_input(INPUT_POST, 'Ring1Att10');
$exploded_valuering110 = explode('|', $Ring110);
$Ring1101 = $exploded_valuering110[0];
$Ring1102 = $exploded_valuering110[1];
$Ring1103 = $exploded_valuering110[2];

$Ring111_1 = filter_input(INPUT_POST, 'Ring1Att11');
$exploded_valuering111 = explode('|', $Ring111_1);
$Ring1111 = $exploded_valuering111[0];
$Ring1112 = $exploded_valuering111[1];
$Ring1113 = $exploded_valuering111[2];
$Ring1114 = $exploded_valuering111[3];

$Ring112_1 = filter_input(INPUT_POST, 'Ring1Att12');
$exploded_valuering112 = explode('|', $Ring112_1);
$Ring1121 = $exploded_valuering112[0];
$Ring1122 = $exploded_valuering112[1];
$Ring1123 = $exploded_valuering112[2];
$Ring1124 = $exploded_valuering112[3];

$Ring113_1 = filter_input(INPUT_POST, 'Ring1Att13');
$exploded_valuering113 = explode('|', $Ring113_1);
$Ring1131 = $exploded_valuering113[0];
$Ring1132 = $exploded_valuering113[1];
$Ring1133 = $exploded_valuering113[2];
$Ring1134 = $exploded_valuering113[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Ring2
$Ring21val = (int)$_POST["Ring21val"];
$Ring22val = (int)$_POST["Ring22val"];
$Ring23val = (int)$_POST["Ring23val"];
$Ring24val = (int)$_POST["Ring24val"];
$Ring25val = (int)$_POST["Ring25val"];
$Ring26val = (int)$_POST["Ring26val"];
$Ring27val = (int)$_POST["Ring27val"];
$Ring28val = (int)$_POST["Ring28val"];
$Ring29val = (int)$_POST["Ring29val"];
$Ring210val = (int)$_POST["Ring210val"];
$Ring211val1 = (int)$_POST["Ring211val1"];
$Ring211val2 = (int)$_POST["Ring211val2"];
$Ring212val1 = (int)$_POST["Ring212val1"];
$Ring212val2 = (int)$_POST["Ring212val2"];
$Ring213val1 = (int)$_POST["Ring213val1"];
$Ring213val2 = (int)$_POST["Ring213val2"];

$Ring21 = filter_input(INPUT_POST, 'Ring2Att1');
$exploded_valuering21 = explode('|', $Ring21);
$Ring211 = $exploded_valuering21[0];
$Ring212 = $exploded_valuering21[1];
$Ring213 = $exploded_valuering21[2];

$Ring22 = filter_input(INPUT_POST, 'Ring2Att2');
$exploded_valuering22 = explode('|', $Ring22);
$Ring221 = $exploded_valuering22[0];
$Ring222 = $exploded_valuering22[1];
$Ring223 = $exploded_valuering22[2];

$Ring23 = filter_input(INPUT_POST, 'Ring2Att3');
$exploded_valuering23 = explode('|', $Ring23);
$Ring231 = $exploded_valuering23[0];
$Ring232 = $exploded_valuering23[1];
$Ring233 = $exploded_valuering23[2];

$Ring24 = filter_input(INPUT_POST, 'Ring2Att4');
$exploded_valuering24 = explode('|', $Ring24);
$Ring241 = $exploded_valuering24[0];
$Ring242 = $exploded_valuering24[1];
$Ring243 = $exploded_valuering24[2];

$Ring25 = filter_input(INPUT_POST, 'Ring2Att5');
$exploded_valuering25 = explode('|', $Ring25);
$Ring251 = $exploded_valuering25[0];
$Ring252 = $exploded_valuering25[1];
$Ring253 = $exploded_valuering25[2];

$Ring26 = filter_input(INPUT_POST, 'Ring2Att6');
$exploded_valuering26 = explode('|', $Ring26);
$Ring261 = $exploded_valuering26[0];
$Ring262 = $exploded_valuering26[1];
$Ring263 = $exploded_valuering26[2];

$Ring27 = filter_input(INPUT_POST, 'Ring2Att7');
$exploded_valuering27 = explode('|', $Ring27);
$Ring271 = $exploded_valuering27[0];
$Ring272 = $exploded_valuering27[1];
$Ring273 = $exploded_valuering27[2];

$Ring28 = filter_input(INPUT_POST, 'Ring2Att8');
$exploded_valuering28 = explode('|', $Ring28);
$Ring281 = $exploded_valuering28[0];
$Ring282 = $exploded_valuering28[1];
$Ring283 = $exploded_valuering28[2];

$Ring29 = filter_input(INPUT_POST, 'Ring2Att9');
$exploded_valuering29 = explode('|', $Ring29);
$Ring291 = $exploded_valuering29[0];
$Ring292 = $exploded_valuering29[1];
$Ring293 = $exploded_valuering29[2];

$Ring210 = filter_input(INPUT_POST, 'Ring2Att10');
$exploded_valuering210 = explode('|', $Ring210);
$Ring2101 = $exploded_valuering210[0];
$Ring2102 = $exploded_valuering210[1];
$Ring2103 = $exploded_valuering210[2];

$Ring211_1 = filter_input(INPUT_POST, 'Ring2Att11');
$exploded_valuering211 = explode('|', $Ring211_1);
$Ring2111 = $exploded_valuering211[0];
$Ring2112 = $exploded_valuering211[1];
$Ring2113 = $exploded_valuering211[2];
$Ring2114 = $exploded_valuering211[3];

$Ring212_1 = filter_input(INPUT_POST, 'Ring2Att12');
$exploded_valuering212 = explode('|', $Ring212_1);
$Ring2121 = $exploded_valuering212[0];
$Ring2122 = $exploded_valuering212[1];
$Ring2123 = $exploded_valuering212[2];
$Ring2124 = $exploded_valuering212[3];

$Ring213_1 = filter_input(INPUT_POST, 'Ring2Att13');
$exploded_valuering213 = explode('|', $Ring213_1);
$Ring2131 = $exploded_valuering213[0];
$Ring2132 = $exploded_valuering213[1];
$Ring2133 = $exploded_valuering213[2];
$Ring2134 = $exploded_valuering213[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Belt
$Belt1val = (int)$_POST["Belt1val"];
$Belt2val = (int)$_POST["Belt2val"];
$Belt3val = (int)$_POST["Belt3val"];
$Belt4val = (int)$_POST["Belt4val"];
$Belt5val = (int)$_POST["Belt5val"];
$Belt6val = (int)$_POST["Belt6val"];
$Belt7val = (int)$_POST["Belt7val"];
$Belt8val = (int)$_POST["Belt8val"];
$Belt9val = (int)$_POST["Belt9val"];
$Belt10val = (int)$_POST["Belt10val"];
$Belt11val1 = (int)$_POST["Belt11val1"];
$Belt11val2 = (int)$_POST["Belt11val2"];
$Belt12val1 = (int)$_POST["Belt12val1"];
$Belt12val2 = (int)$_POST["Belt12val2"];
$Belt13val1 = (int)$_POST["Belt13val1"];
$Belt13val2 = (int)$_POST["Belt13val2"];

$Belt1 = filter_input(INPUT_POST, 'BeltAtt1');
$exploded_valueboot1 = explode('|', $Belt1);
$Belt11 = $exploded_valueboot1[0];
$Belt12 = $exploded_valueboot1[1];
$Belt13 = $exploded_valueboot1[2];

$Belt2 = filter_input(INPUT_POST, 'BeltAtt2');
$exploded_valueboot2 = explode('|', $Belt2);
$Belt21 = $exploded_valueboot2[0];
$Belt22 = $exploded_valueboot2[1];
$Belt23 = $exploded_valueboot2[2];

$Belt3 = filter_input(INPUT_POST, 'BeltAtt3');
$exploded_valueboot3 = explode('|', $Belt3);
$Belt31 = $exploded_valueboot3[0];
$Belt32 = $exploded_valueboot3[1];
$Belt33 = $exploded_valueboot3[2];

$Belt4 = filter_input(INPUT_POST, 'BeltAtt4');
$exploded_valueboot4 = explode('|', $Belt4);
$Belt41 = $exploded_valueboot4[0];
$Belt42 = $exploded_valueboot4[1];
$Belt43 = $exploded_valueboot4[2];

$Belt5 = filter_input(INPUT_POST, 'BeltAtt5');
$exploded_valueboot5 = explode('|', $Belt5);
$Belt51 = $exploded_valueboot5[0];
$Belt52 = $exploded_valueboot5[1];
$Belt53 = $exploded_valueboot5[2];

$Belt6 = filter_input(INPUT_POST, 'BeltAtt6');
$exploded_valueboot6 = explode('|', $Belt6);
$Belt61 = $exploded_valueboot6[0];
$Belt62 = $exploded_valueboot6[1];
$Belt63 = $exploded_valueboot6[2];

$Belt7 = filter_input(INPUT_POST, 'BeltAtt7');
$exploded_valueboot7 = explode('|', $Belt7);
$Belt71 = $exploded_valueboot7[0];
$Belt72 = $exploded_valueboot7[1];
$Belt73 = $exploded_valueboot7[2];

$Belt8 = filter_input(INPUT_POST, 'BeltAtt8');
$exploded_valueboot8 = explode('|', $Belt8);
$Belt81 = $exploded_valueboot8[0];
$Belt82 = $exploded_valueboot8[1];
$Belt83 = $exploded_valueboot8[2];

$Belt9 = filter_input(INPUT_POST, 'BeltAtt9');
$exploded_valueboot9 = explode('|', $Belt9);
$Belt91 = $exploded_valueboot9[0];
$Belt92 = $exploded_valueboot9[1];
$Belt93 = $exploded_valueboot9[2];

$Belt10 = filter_input(INPUT_POST, 'BeltAtt10');
$exploded_valueboot10 = explode('|', $Belt10);
$Belt101 = $exploded_valueboot10[0];
$Belt102 = $exploded_valueboot10[1];
$Belt103 = $exploded_valueboot10[2];

$Belt11_1 = filter_input(INPUT_POST, 'BeltAtt11');
$exploded_valueboot11 = explode('|', $Belt11_1);
$Belt111 = $exploded_valueboot11[0];
$Belt112 = $exploded_valueboot11[1];
$Belt113 = $exploded_valueboot11[2];
$Belt114 = $exploded_valueboot11[3];

$Belt12_1 = filter_input(INPUT_POST, 'BeltAtt12');
$exploded_valueboot12 = explode('|', $Belt12_1);
$Belt121 = $exploded_valueboot12[0];
$Belt122 = $exploded_valueboot12[1];
$Belt123 = $exploded_valueboot12[2];
$Belt124 = $exploded_valueboot12[3];

$Belt13_1 = filter_input(INPUT_POST, 'BeltAtt13');
$exploded_valueboot13 = explode('|', $Belt13_1);
$Belt131 = $exploded_valueboot13[0];
$Belt132 = $exploded_valueboot13[1];
$Belt133 = $exploded_valueboot13[2];
$Belt134 = $exploded_valueboot13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Amulet
$Amulet1val = (int)$_POST["Amulet1val"];
$Amulet2val = (int)$_POST["Amulet2val"];
$Amulet3val = (int)$_POST["Amulet3val"];
$Amulet4val = (int)$_POST["Amulet4val"];
$Amulet5val = (int)$_POST["Amulet5val"];
$Amulet6val = (int)$_POST["Amulet6val"];
$Amulet7val = (int)$_POST["Amulet7val"];
$Amulet8val = (int)$_POST["Amulet8val"];
$Amulet9val = (int)$_POST["Amulet9val"];
$Amulet10val = (int)$_POST["Amulet10val"];
$Amulet11val1 = (int)$_POST["Amulet11val1"];
$Amulet11val2 = (int)$_POST["Amulet11val2"];
$Amulet12val1 = (int)$_POST["Amulet12val1"];
$Amulet12val2 = (int)$_POST["Amulet12val2"];
$Amulet13val1 = (int)$_POST["Amulet13val1"];
$Amulet13val2 = (int)$_POST["Amulet13val2"];

$Amulet1 = filter_input(INPUT_POST, 'AmuletAtt1');
$exploded_valueboot1 = explode('|', $Amulet1);
$Amulet11 = $exploded_valueboot1[0];
$Amulet12 = $exploded_valueboot1[1];
$Amulet13 = $exploded_valueboot1[2];

$Amulet2 = filter_input(INPUT_POST, 'AmuletAtt2');
$exploded_valueboot2 = explode('|', $Amulet2);
$Amulet21 = $exploded_valueboot2[0];
$Amulet22 = $exploded_valueboot2[1];
$Amulet23 = $exploded_valueboot2[2];

$Amulet3 = filter_input(INPUT_POST, 'AmuletAtt3');
$exploded_valueboot3 = explode('|', $Amulet3);
$Amulet31 = $exploded_valueboot3[0];
$Amulet32 = $exploded_valueboot3[1];
$Amulet33 = $exploded_valueboot3[2];

$Amulet4 = filter_input(INPUT_POST, 'AmuletAtt4');
$exploded_valueboot4 = explode('|', $Amulet4);
$Amulet41 = $exploded_valueboot4[0];
$Amulet42 = $exploded_valueboot4[1];
$Amulet43 = $exploded_valueboot4[2];

$Amulet5 = filter_input(INPUT_POST, 'AmuletAtt5');
$exploded_valueboot5 = explode('|', $Amulet5);
$Amulet51 = $exploded_valueboot5[0];
$Amulet52 = $exploded_valueboot5[1];
$Amulet53 = $exploded_valueboot5[2];

$Amulet6 = filter_input(INPUT_POST, 'AmuletAtt6');
$exploded_valueboot6 = explode('|', $Amulet6);
$Amulet61 = $exploded_valueboot6[0];
$Amulet62 = $exploded_valueboot6[1];
$Amulet63 = $exploded_valueboot6[2];

$Amulet7 = filter_input(INPUT_POST, 'AmuletAtt7');
$exploded_valueboot7 = explode('|', $Amulet7);
$Amulet71 = $exploded_valueboot7[0];
$Amulet72 = $exploded_valueboot7[1];
$Amulet73 = $exploded_valueboot7[2];

$Amulet8 = filter_input(INPUT_POST, 'AmuletAtt8');
$exploded_valueboot8 = explode('|', $Amulet8);
$Amulet81 = $exploded_valueboot8[0];
$Amulet82 = $exploded_valueboot8[1];
$Amulet83 = $exploded_valueboot8[2];

$Amulet9 = filter_input(INPUT_POST, 'AmuletAtt9');
$exploded_valueboot9 = explode('|', $Amulet9);
$Amulet91 = $exploded_valueboot9[0];
$Amulet92 = $exploded_valueboot9[1];
$Amulet93 = $exploded_valueboot9[2];

$Amulet10 = filter_input(INPUT_POST, 'AmuletAtt10');
$exploded_valueboot10 = explode('|', $Amulet10);
$Amulet101 = $exploded_valueboot10[0];
$Amulet102 = $exploded_valueboot10[1];
$Amulet103 = $exploded_valueboot10[2];

$Amulet11_1 = filter_input(INPUT_POST, 'AmuletAtt11');
$exploded_valueboot11 = explode('|', $Amulet11_1);
$Amulet111 = $exploded_valueboot11[0];
$Amulet112 = $exploded_valueboot11[1];
$Amulet113 = $exploded_valueboot11[2];
$Amulet114 = $exploded_valueboot11[3];

$Amulet12_1 = filter_input(INPUT_POST, 'AmuletAtt12');
$exploded_valueboot12 = explode('|', $Amulet12_1);
$Amulet121 = $exploded_valueboot12[0];
$Amulet122 = $exploded_valueboot12[1];
$Amulet123 = $exploded_valueboot12[2];
$Amulet124 = $exploded_valueboot12[3];

$Amulet13_1 = filter_input(INPUT_POST, 'AmuletAtt13');
$exploded_valueboot13 = explode('|', $Amulet13_1);
$Amulet131 = $exploded_valueboot13[0];
$Amulet132 = $exploded_valueboot13[1];
$Amulet133 = $exploded_valueboot13[2];
$Amulet134 = $exploded_valueboot13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//MainHand
$MH1 = filter_input(INPUT_POST, 'mainhandtype');
$exploded_valuemha1 = explode('|', $MH1);
$MH11 = $exploded_valuemha1[0];
$MH12 = $exploded_valuemha1[1];

$MainHandAffix1val = (int)$_POST["MainHandAffix1val"];
$MainHandAffix2val = (int)$_POST["MainHandAffix2val"];
$MainHandAffix3val = (int)$_POST["MainHandAffix3val"];
$MainHand1val = (int)$_POST["MainHand1val"];
$MainHand2val = (int)$_POST["MainHand2val"];
$MainHand3val = (int)$_POST["MainHand3val"];
$MainHand4val = (int)$_POST["MainHand4val"];
$MainHand5val = (int)$_POST["MainHand5val"];
$MainHand6val = (int)$_POST["MainHand6val"];
$MainHand7val = (int)$_POST["MainHand7val"];
$MainHand8val = (int)$_POST["MainHand8val"];
$MainHand9val = (int)$_POST["MainHand9val"];
$MainHand10val = (int)$_POST["MainHand10val"];
$MainHand11val1 = (int)$_POST["MainHand11val1"];
$MainHand11val2 = (int)$_POST["MainHand11val2"];
$MainHand12val1 = (int)$_POST["MainHand12val1"];
$MainHand12val2 = (int)$_POST["MainHand12val2"];
$MainHand13val1 = (int)$_POST["MainHand13val1"];
$MainHand13val2 = (int)$_POST["MainHand13val2"];

$MainHand1 = filter_input(INPUT_POST, 'MainHandAtt1');
$exploded_valuemhand1 = explode('|', $MainHand1);
$MainHand11 = $exploded_valuemhand1[0];
$MainHand12 = $exploded_valuemhand1[1];
$MainHand13 = $exploded_valuemhand1[2];

$MainHand2 = filter_input(INPUT_POST, 'MainHandAtt2');
$exploded_valuemhand2 = explode('|', $MainHand2);
$MainHand21 = $exploded_valuemhand2[0];
$MainHand22 = $exploded_valuemhand2[1];
$MainHand23 = $exploded_valuemhand2[2];

$MainHand3 = filter_input(INPUT_POST, 'MainHandAtt3');
$exploded_valuemhand3 = explode('|', $MainHand3);
$MainHand31 = $exploded_valuemhand3[0];
$MainHand32 = $exploded_valuemhand3[1];
$MainHand33 = $exploded_valuemhand3[2];

$MainHand4 = filter_input(INPUT_POST, 'MainHandAtt4');
$exploded_valuemhand4 = explode('|', $MainHand4);
$MainHand41 = $exploded_valuemhand4[0];
$MainHand42 = $exploded_valuemhand4[1];
$MainHand43 = $exploded_valuemhand4[2];

$MainHand5 = filter_input(INPUT_POST, 'MainHandAtt5');
$exploded_valuemhand5 = explode('|', $MainHand5);
$MainHand51 = $exploded_valuemhand5[0];
$MainHand52 = $exploded_valuemhand5[1];
$MainHand53 = $exploded_valuemhand5[2];

$MainHand6 = filter_input(INPUT_POST, 'MainHandAtt6');
$exploded_valuemhand6 = explode('|', $MainHand6);
$MainHand61 = $exploded_valuemhand6[0];
$MainHand62 = $exploded_valuemhand6[1];
$MainHand63 = $exploded_valuemhand6[2];

$MainHand7 = filter_input(INPUT_POST, 'MainHandAtt7');
$exploded_valuemhand7 = explode('|', $MainHand7);
$MainHand71 = $exploded_valuemhand7[0];
$MainHand72 = $exploded_valuemhand7[1];
$MainHand73 = $exploded_valuemhand7[2];

$MainHand8 = filter_input(INPUT_POST, 'MainHandAtt8');
$exploded_valuemhand8 = explode('|', $MainHand8);
$MainHand81 = $exploded_valuemhand8[0];
$MainHand82 = $exploded_valuemhand8[1];
$MainHand83 = $exploded_valuemhand8[2];

$MainHand9 = filter_input(INPUT_POST, 'MainHandAtt9');
$exploded_valuemhand9 = explode('|', $MainHand9);
$MainHand91 = $exploded_valuemhand9[0];
$MainHand92 = $exploded_valuemhand9[1];
$MainHand93 = $exploded_valuemhand9[2];

$MainHand10 = filter_input(INPUT_POST, 'MainHandAtt10');
$exploded_valuemhand10 = explode('|', $MainHand10);
$MainHand101 = $exploded_valuemhand10[0];
$MainHand102 = $exploded_valuemhand10[1];
$MainHand103 = $exploded_valuemhand10[2];

$MainHand11_1 = filter_input(INPUT_POST, 'MainHandAtt11');
$exploded_valuemhand11 = explode('|', $MainHand11_1);
$MainHand111 = $exploded_valuemhand11[0];
$MainHand112 = $exploded_valuemhand11[1];
$MainHand113 = $exploded_valuemhand11[2];
$MainHand114 = $exploded_valuemhand11[3];

$MainHand12_1 = filter_input(INPUT_POST, 'MainHandAtt12');
$exploded_valuemhand12 = explode('|', $MainHand12_1);
$MainHand121 = $exploded_valuemhand12[0];
$MainHand122 = $exploded_valuemhand12[1];
$MainHand123 = $exploded_valuemhand12[2];
$MainHand124 = $exploded_valuemhand12[3];

$MainHand13_1 = filter_input(INPUT_POST, 'MainHandAtt13');
$exploded_valuemhand13 = explode('|', $MainHand13_1);
$MainHand131 = $exploded_valuemhand13[0];
$MainHand132 = $exploded_valuemhand13[1];
$MainHand133 = $exploded_valuemhand13[2];
$MainHand134 = $exploded_valuemhand13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//OffHand
$OH1 = filter_input(INPUT_POST, 'offhandtype');
$exploded_valueoha1 = explode('|', $OH1);
$OH11 = $exploded_valueoha1[0];
$OH12 = $exploded_valueoha1[1];

$OffHandAffix1val = (int)$_POST["OffHandAffix1val"];
$OffHandAffix2val = (int)$_POST["OffHandAffix2val"];
$OffHandAffix3val = (int)$_POST["OffHandAffix3val"];
$OffHand1val = (int)$_POST["OffHand1val"];
$OffHand2val = (int)$_POST["OffHand2val"];
$OffHand3val = (int)$_POST["OffHand3val"];
$OffHand4val = (int)$_POST["OffHand4val"];
$OffHand5val = (int)$_POST["OffHand5val"];
$OffHand6val = (int)$_POST["OffHand6val"];
$OffHand7val = (int)$_POST["OffHand7val"];
$OffHand8val = (int)$_POST["OffHand8val"];
$OffHand9val = (int)$_POST["OffHand9val"];
$OffHand10val = (int)$_POST["OffHand10val"];
$OffHand11val1 = (int)$_POST["OffHand11val1"];
$OffHand11val2 = (int)$_POST["OffHand11val2"];
$OffHand12val1 = (int)$_POST["OffHand12val1"];
$OffHand12val2 = (int)$_POST["OffHand12val2"];
$OffHand13val1 = (int)$_POST["OffHand13val1"];
$OffHand13val2 = (int)$_POST["OffHand13val2"];

$OffHand1 = filter_input(INPUT_POST, 'OffHandAtt1');
$exploded_valueohand1 = explode('|', $OffHand1);
$OffHand11 = $exploded_valueohand1[0];
$OffHand12 = $exploded_valueohand1[1];
$OffHand13 = $exploded_valueohand1[2];

$OffHand2 = filter_input(INPUT_POST, 'OffHandAtt2');
$exploded_valueohand2 = explode('|', $OffHand2);
$OffHand21 = $exploded_valueohand2[0];
$OffHand22 = $exploded_valueohand2[1];
$OffHand23 = $exploded_valueohand2[2];

$OffHand3 = filter_input(INPUT_POST, 'OffHandAtt3');
$exploded_valueohand3 = explode('|', $OffHand3);
$OffHand31 = $exploded_valueohand3[0];
$OffHand32 = $exploded_valueohand3[1];
$OffHand33 = $exploded_valueohand3[2];

$OffHand4 = filter_input(INPUT_POST, 'OffHandAtt4');
$exploded_valueohand4 = explode('|', $OffHand4);
$OffHand41 = $exploded_valueohand4[0];
$OffHand42 = $exploded_valueohand4[1];
$OffHand43 = $exploded_valueohand4[2];

$OffHand5 = filter_input(INPUT_POST, 'OffHandAtt5');
$exploded_valueohand5 = explode('|', $OffHand5);
$OffHand51 = $exploded_valueohand5[0];
$OffHand52 = $exploded_valueohand5[1];
$OffHand53 = $exploded_valueohand5[2];

$OffHand6 = filter_input(INPUT_POST, 'OffHandAtt6');
$exploded_valueohand6 = explode('|', $OffHand6);
$OffHand61 = $exploded_valueohand6[0];
$OffHand62 = $exploded_valueohand6[1];
$OffHand63 = $exploded_valueohand6[2];

$OffHand7 = filter_input(INPUT_POST, 'OffHandAtt7');
$exploded_valueohand7 = explode('|', $OffHand7);
$OffHand71 = $exploded_valueohand7[0];
$OffHand72 = $exploded_valueohand7[1];
$OffHand73 = $exploded_valueohand7[2];

$OffHand8 = filter_input(INPUT_POST, 'OffHandAtt8');
$exploded_valueohand8 = explode('|', $OffHand8);
$OffHand81 = $exploded_valueohand8[0];
$OffHand82 = $exploded_valueohand8[1];
$OffHand83 = $exploded_valueohand8[2];

$OffHand9 = filter_input(INPUT_POST, 'OffHandAtt9');
$exploded_valueohand9 = explode('|', $OffHand9);
$OffHand91 = $exploded_valueohand9[0];
$OffHand92 = $exploded_valueohand9[1];
$OffHand93 = $exploded_valueohand9[2];

$OffHand10 = filter_input(INPUT_POST, 'OffHandAtt10');
$exploded_valueohand10 = explode('|', $OffHand10);
$OffHand101 = $exploded_valueohand10[0];
$OffHand102 = $exploded_valueohand10[1];
$OffHand103 = $exploded_valueohand10[2];

$OffHand11_1 = filter_input(INPUT_POST, 'OffHandAtt11');
$exploded_valueohand11 = explode('|', $OffHand11_1);
$OffHand111 = $exploded_valueohand11[0];
$OffHand112 = $exploded_valueohand11[1];
$OffHand113 = $exploded_valueohand11[2];
$OffHand114 = $exploded_valueohand11[3];

$OffHand12_1 = filter_input(INPUT_POST, 'OffHandAtt12');
$exploded_valueohand12 = explode('|', $OffHand12_1);
$OffHand121 = $exploded_valueohand12[0];
$OffHand122 = $exploded_valueohand12[1];
$OffHand123 = $exploded_valueohand12[2];
$OffHand124 = $exploded_valueohand12[3];

$OffHand13_1 = filter_input(INPUT_POST, 'OffHandAtt13');
$exploded_valueohand13 = explode('|', $OffHand13_1);
$OffHand131 = $exploded_valueohand13[0];
$OffHand132 = $exploded_valueohand13[1];
$OffHand133 = $exploded_valueohand13[2];
$OffHand134 = $exploded_valueohand13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Shield
$ShieldAffix1val = (int)$_POST["ShieldAffix1val"];
$ShieldAffix2val = (int)$_POST["ShieldAffix2val"];
$ShieldAffix3val = (int)$_POST["ShieldAffix3val"];
$ShieldAffix4val = (int)$_POST["ShieldAffix4val"];
$ShieldAffix5val = (int)$_POST["ShieldAffix5val"];
$Shield1val = (int)$_POST["Shield1val"];
$Shield2val = (int)$_POST["Shield2val"];
$Shield3val = (int)$_POST["Shield3val"];
$Shield4val = (int)$_POST["Shield4val"];
$Shield5val = (int)$_POST["Shield5val"];
$Shield6val = (int)$_POST["Shield6val"];
$Shield7val = (int)$_POST["Shield7val"];
$Shield8val = (int)$_POST["Shield8val"];
$Shield9val = (int)$_POST["Shield9val"];
$Shield10val = (int)$_POST["Shield10val"];
$Shield11val1 = (int)$_POST["Shield11val1"];
$Shield11val2 = (int)$_POST["Shield11val2"];
$Shield12val1 = (int)$_POST["Shield12val1"];
$Shield12val2 = (int)$_POST["Shield12val2"];
$Shield13val1 = (int)$_POST["Shield13val1"];
$Shield13val2 = (int)$_POST["Shield13val2"];

$Shield1 = filter_input(INPUT_POST, 'ShieldAtt1');
$exploded_valueshield1 = explode('|', $Shield1);
$Shield11 = $exploded_valueshield1[0];
$Shield12 = $exploded_valueshield1[1];
$Shield13 = $exploded_valueshield1[2];

$Shield2 = filter_input(INPUT_POST, 'ShieldAtt2');
$exploded_valueshield2 = explode('|', $Shield2);
$Shield21 = $exploded_valueshield2[0];
$Shield22 = $exploded_valueshield2[1];
$Shield23 = $exploded_valueshield2[2];

$Shield3 = filter_input(INPUT_POST, 'ShieldAtt3');
$exploded_valueshield3 = explode('|', $Shield3);
$Shield31 = $exploded_valueshield3[0];
$Shield32 = $exploded_valueshield3[1];
$Shield33 = $exploded_valueshield3[2];

$Shield4 = filter_input(INPUT_POST, 'ShieldAtt4');
$exploded_valueshield4 = explode('|', $Shield4);
$Shield41 = $exploded_valueshield4[0];
$Shield42 = $exploded_valueshield4[1];
$Shield43 = $exploded_valueshield4[2];

$Shield5 = filter_input(INPUT_POST, 'ShieldAtt5');
$exploded_valueshield5 = explode('|', $Shield5);
$Shield51 = $exploded_valueshield5[0];
$Shield52 = $exploded_valueshield5[1];
$Shield53 = $exploded_valueshield5[2];

$Shield6 = filter_input(INPUT_POST, 'ShieldAtt6');
$exploded_valueshield6 = explode('|', $Shield6);
$Shield61 = $exploded_valueshield6[0];
$Shield62 = $exploded_valueshield6[1];
$Shield63 = $exploded_valueshield6[2];

$Shield7 = filter_input(INPUT_POST, 'ShieldAtt7');
$exploded_valueshield7 = explode('|', $Shield7);
$Shield71 = $exploded_valueshield7[0];
$Shield72 = $exploded_valueshield7[1];
$Shield73 = $exploded_valueshield7[2];

$Shield8 = filter_input(INPUT_POST, 'ShieldAtt8');
$exploded_valueshield8 = explode('|', $Shield8);
$Shield81 = $exploded_valueshield8[0];
$Shield82 = $exploded_valueshield8[1];
$Shield83 = $exploded_valueshield8[2];

$Shield9 = filter_input(INPUT_POST, 'ShieldAtt9');
$exploded_valueshield9 = explode('|', $Shield9);
$Shield91 = $exploded_valueshield9[0];
$Shield92 = $exploded_valueshield9[1];
$Shield93 = $exploded_valueshield9[2];

$Shield10 = filter_input(INPUT_POST, 'ShieldAtt10');
$exploded_valueshield10 = explode('|', $Shield10);
$Shield101 = $exploded_valueshield10[0];
$Shield102 = $exploded_valueshield10[1];
$Shield103 = $exploded_valueshield10[2];

$Shield11_1 = filter_input(INPUT_POST, 'ShieldAtt11');
$exploded_valueshield11 = explode('|', $Shield11_1);
$Shield111 = $exploded_valueshield11[0];
$Shield112 = $exploded_valueshield11[1];
$Shield113 = $exploded_valueshield11[2];
$Shield114 = $exploded_valueshield11[3];

$Shield12_1 = filter_input(INPUT_POST, 'ShieldAtt12');
$exploded_valueshield12 = explode('|', $Shield12_1);
$Shield121 = $exploded_valueshield12[0];
$Shield122 = $exploded_valueshield12[1];
$Shield123 = $exploded_valueshield12[2];
$Shield124 = $exploded_valueshield12[3];

$Shield13_1 = filter_input(INPUT_POST, 'ShieldAtt13');
$exploded_valueshield13 = explode('|', $Shield13_1);
$Shield131 = $exploded_valueshield13[0];
$Shield132 = $exploded_valueshield13[1];
$Shield133 = $exploded_valueshield13[2];
$Shield134 = $exploded_valueshield13[3];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Catalyst
$CatalystAffix1val = (int)$_POST["CatalystAffix1val"];
$CatalystAffix2val = (int)$_POST["CatalystAffix2val"];
$Catalyst1val = (int)$_POST["Catalyst1val"];
$Catalyst2val = (int)$_POST["Catalyst2val"];
$Catalyst3val = (int)$_POST["Catalyst3val"];
$Catalyst4val = (int)$_POST["Catalyst4val"];
$Catalyst5val = (int)$_POST["Catalyst5val"];
$Catalyst6val = (int)$_POST["Catalyst6val"];
$Catalyst7val = (int)$_POST["Catalyst7val"];
$Catalyst8val = (int)$_POST["Catalyst8val"];
$Catalyst9val = (int)$_POST["Catalyst9val"];
$Catalyst10val = (int)$_POST["Catalyst10val"];
$Catalyst11val1 = (int)$_POST["Catalyst11val1"];
$Catalyst11val2 = (int)$_POST["Catalyst11val2"];
$Catalyst12val1 = (int)$_POST["Catalyst12val1"];
$Catalyst12val2 = (int)$_POST["Catalyst12val2"];
$Catalyst13val1 = (int)$_POST["Catalyst13val1"];
$Catalyst13val2 = (int)$_POST["Catalyst13val2"];

$Catalyst1 = filter_input(INPUT_POST, 'CatalystAtt1');
$exploded_valueCatalyst1 = explode('|', $Catalyst1);
$Catalyst11 = $exploded_valueCatalyst1[0];
$Catalyst12 = $exploded_valueCatalyst1[1];
$Catalyst13 = $exploded_valueCatalyst1[2];

$Catalyst2 = filter_input(INPUT_POST, 'CatalystAtt2');
$exploded_valueCatalyst2 = explode('|', $Catalyst2);
$Catalyst21 = $exploded_valueCatalyst2[0];
$Catalyst22 = $exploded_valueCatalyst2[1];
$Catalyst23 = $exploded_valueCatalyst2[2];

$Catalyst3 = filter_input(INPUT_POST, 'CatalystAtt3');
$exploded_valueCatalyst3 = explode('|', $Catalyst3);
$Catalyst31 = $exploded_valueCatalyst3[0];
$Catalyst32 = $exploded_valueCatalyst3[1];
$Catalyst33 = $exploded_valueCatalyst3[2];

$Catalyst4 = filter_input(INPUT_POST, 'CatalystAtt4');
$exploded_valueCatalyst4 = explode('|', $Catalyst4);
$Catalyst41 = $exploded_valueCatalyst4[0];
$Catalyst42 = $exploded_valueCatalyst4[1];
$Catalyst43 = $exploded_valueCatalyst4[2];

$Catalyst5 = filter_input(INPUT_POST, 'CatalystAtt5');
$exploded_valueCatalyst5 = explode('|', $Catalyst5);
$Catalyst51 = $exploded_valueCatalyst5[0];
$Catalyst52 = $exploded_valueCatalyst5[1];
$Catalyst53 = $exploded_valueCatalyst5[2];

$Catalyst6 = filter_input(INPUT_POST, 'CatalystAtt6');
$exploded_valueCatalyst6 = explode('|', $Catalyst6);
$Catalyst61 = $exploded_valueCatalyst6[0];
$Catalyst62 = $exploded_valueCatalyst6[1];
$Catalyst63 = $exploded_valueCatalyst6[2];

$Catalyst7 = filter_input(INPUT_POST, 'CatalystAtt7');
$exploded_valueCatalyst7 = explode('|', $Catalyst7);
$Catalyst71 = $exploded_valueCatalyst7[0];
$Catalyst72 = $exploded_valueCatalyst7[1];
$Catalyst73 = $exploded_valueCatalyst7[2];

$Catalyst8 = filter_input(INPUT_POST, 'CatalystAtt8');
$exploded_valueCatalyst8 = explode('|', $Catalyst8);
$Catalyst81 = $exploded_valueCatalyst8[0];
$Catalyst82 = $exploded_valueCatalyst8[1];
$Catalyst83 = $exploded_valueCatalyst8[2];

$Catalyst9 = filter_input(INPUT_POST, 'CatalystAtt9');
$exploded_valueCatalyst9 = explode('|', $Catalyst9);
$Catalyst91 = $exploded_valueCatalyst9[0];
$Catalyst92 = $exploded_valueCatalyst9[1];
$Catalyst93 = $exploded_valueCatalyst9[2];

$Catalyst10 = filter_input(INPUT_POST, 'CatalystAtt10');
$exploded_valueCatalyst10 = explode('|', $Catalyst10);
$Catalyst101 = $exploded_valueCatalyst10[0];
$Catalyst102 = $exploded_valueCatalyst10[1];
$Catalyst103 = $exploded_valueCatalyst10[2];

$Catalyst11_1 = filter_input(INPUT_POST, 'CatalystAtt11');
$exploded_valueCatalyst11 = explode('|', $Catalyst11_1);
$Catalyst111 = $exploded_valueCatalyst11[0];
$Catalyst112 = $exploded_valueCatalyst11[1];
$Catalyst113 = $exploded_valueCatalyst11[2];
$Catalyst114 = $exploded_valueCatalyst11[3];

$Catalyst12_1 = filter_input(INPUT_POST, 'CatalystAtt12');
$exploded_valueCatalyst12 = explode('|', $Catalyst12_1);
$Catalyst121 = $exploded_valueCatalyst12[0];
$Catalyst122 = $exploded_valueCatalyst12[1];
$Catalyst123 = $exploded_valueCatalyst12[2];
$Catalyst124 = $exploded_valueCatalyst12[3];

$Catalyst13_1 = filter_input(INPUT_POST, 'CatalystAtt13');
$exploded_valueCatalyst13 = explode('|', $Catalyst13_1);
$Catalyst131 = $exploded_valueCatalyst13[0];
$Catalyst132 = $exploded_valueCatalyst13[1];
$Catalyst133 = $exploded_valueCatalyst13[2];
$Catalyst134 = $exploded_valueCatalyst13[3];

//JSON

$data['Name'] = $name;
$data['CharacterId'] = $name;
$data['Stats'] = [
        "Strength" => 1,
        "Agility" => 1,
        "Constitution" => 1,
        "Power" => 1,
        "Level" => $level,
        "PassiveSkillPoints" => 99999,
        "CurrentXP" => "1",
        "RemainingStatsPoints" => $stats,
        "Gold" => $gold,
        "PrimordialAffinity" => $pmaffin,
        "IsAutoDashAvailable" => 1,
        "DashStatusActivation" => 0
];

$data['Progression'] = [
    "LastPlayed"=>	[
        "QuestId"=>	$actval,
        "StepId"=>	1
    ],
    "QuestProgression"=>	[
        [
        "Name"=>	"ACT1_Quest1",
        "Step"=>	7
    ], [
        "Name"=>	"ACT1_Quest2",
        "Step"=>	7
    ], [
        "Name"=>	"ACT3_Quest1",
        "Step"=>	9
    ], [
        "Name"=>	"ACT3_Quest2",
        "Step"=>	8
    ], [
        "Name"=>	"ACT3_Quest3",
        "Step"=>	8
    ], [
        "Name"=>	"ACT3_Quest4",
        "Step"=>	8
    ], [
        "Name"=>	"INTRO_Quest1",
        "Step"=>	8
    ]
    ]
];

$data['UnlockedSkills'] = [
    [	"SkillName"=>	"player_aetherblade",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_aetherblast",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_arrowsrain",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_bladeslinger",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_bomb",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_brutalstrike",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_bulleye",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_chainlightning",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_charge",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_corpseexplosion",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_deathmark",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_dualstrike",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_fireball",
        "Level"=>	$level,
        "CurrentXp"=>	"183",
        "Variants"=>	"1000000000000000"
    ], [
        "SkillName"=>	"player_frostnova",
        "Level"=>	$level,
        "CurrentXp"=>	"183",
        "Variants"=>	"0100000000000000"
    ], [
        "SkillName"=>	"player_frostcomet",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_frostlance",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_hammer",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_holydive",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_hook",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_ironguard",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_laceration",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0100000001000111"
    ], [
        "SkillName"=>	"player_laser",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_leap",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"1110100000100100"
    ], [
        "SkillName"=>	"player_possession",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_reave",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_sacredground",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_smokebomb",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_sniper",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_solarfall",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_spreadshot",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_summon_melee",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_summon_ranged",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_teleport",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0100100001001001"
    ], [
        "SkillName"=>	"player_turret",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_vault",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_vortex",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0000000000000000"
    ], [
        "SkillName"=>	"player_warcry",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"0110100010110001"
    ], [
        "SkillName"=>	"player_whirlwind",
        "Level"=>	$level,
        "CurrentXp"=>	"0",
        "Variants"=>	"1000010000011011"
    ]
];


$data['InventoryEquipped'] = [
    (object) [
        "BodyPart"=>	3,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Helmet",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Rogue_Helmet_Tier1",
            "Health" => $HelmAffix1val,
            "Armor" => $HelmAffix2val,
            "Resistance" => $HelmAffix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                "EffectId"=> $Hea11,
                "EffectName"=> $Hea12,
                "MaxStack"=> 1,
                "Parameters"=>	[
                        [
                            "semantic" => $Hea13,
                            "value" => $Ha1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Hea21,
                    "EffectName"=> $Hea22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Hea23,
                            "value" => $Ha2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea31",
                    "EffectName"=>	"$Hea32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea33",
                            "value"=>	$Ha3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea41",
                    "EffectName"=>	"$Hea42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea43",
                            "value"=>	$Ha4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea51",
                    "EffectName"=>	"$Hea52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea53",
                            "value"=>	$Ha5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea61",
                    "EffectName"=>	"$Hea62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea63",
                            "value"=>	$Ha6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea71",
                    "EffectName"=>	"$Hea72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea73",
                            "value"=>	$Ha7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea81",
                    "EffectName"=>	"$Hea82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea83",
                            "value"=>	$Ha8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea91",
                    "EffectName"=>	"$Hea92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea93",
                            "value"=>	$Ha9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea101",
                    "EffectName"=>	"$Hea102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea103",
                            "value"=>	$Ha10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea111",
                    "EffectName"=>	"$Hea112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea113",
                            "value"=>	$Ha11val1
                        ],
                        [
                            "semantic"=>	"$Hea114",
                            "value"=>	$Ha11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea121",
                    "EffectName"=>	"$Hea122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea123",
                            "value"=>	$Ha12val1
                        ],
                        [
                            "semantic"=>	"$Hea124",
                            "value"=>	$Ha12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Hea131",
                    "EffectName"=>	"$Hea132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Hea133",
                            "value"=>	$Ha13val1
                        ],
                        [
                            "semantic"=>	"$Hea134",
                            "value"=>	$Ha13val2
                        ]
                    ]
                ]
                            
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	1,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Chest Armor",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Rogue_ChestArmor_Tier1",
            "Health" => $ChestAffix1val,
            "Armor" => $ChestAffix2val,
            "Resistance" => $ChestAffix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Chest11,
                    "EffectName"=> $Chest12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Chest13,
                            "value" => $Che1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Chest21,
                    "EffectName"=> $Chest22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Chest23,
                            "value" => $Che2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest31",
                    "EffectName"=>	"$Chest32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest33",
                            "value"=>	$Che3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest41",
                    "EffectName"=>	"$Chest42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest43",
                            "value"=>	$Che4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest51",
                    "EffectName"=>	"$Chest52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest53",
                            "value"=>	$Che5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest61",
                    "EffectName"=>	"$Chest62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest63",
                            "value"=>	$Che6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest71",
                    "EffectName"=>	"$Chest72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest73",
                            "value"=>	$Che7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest81",
                    "EffectName"=>	"$Chest82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest83",
                            "value"=>	$Che8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest91",
                    "EffectName"=>	"$Chest92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest93",
                            "value"=>	$Che9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest101",
                    "EffectName"=>	"$Chest102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest103",
                            "value"=>	$Che10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest111",
                    "EffectName"=>	"$Chest112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest113",
                            "value"=>	$Che11val1
                        ],
                        [
                            "semantic"=>	"$Chest114",
                            "value"=>	$Che11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest121",
                    "EffectName"=>	"$Chest122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest123",
                            "value"=>	$Che12val1
                        ],
                        [
                            "semantic"=>	"$Chest124",
                            "value"=>	$Che12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Chest131",
                    "EffectName"=>	"$Chest132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Chest133",
                            "value"=>	$Che13val1
                        ],
                        [
                            "semantic"=>	"$Chest134",
                            "value"=>	$Che13val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	11,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Leg Armor",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Rogue_Pants_Tier1",
            "Health" => $LegsAffix1val,
            "Armor" => $LegsAffix2val,
            "Resistance" => $LegsAffix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Legs11,
                    "EffectName"=> $Legs12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Legs13,
                            "value" => $Legs1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Legs21,
                    "EffectName"=> $Legs22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Legs23,
                            "value" => $Legs2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs31",
                    "EffectName"=>	"$Legs32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs33",
                            "value"=>	$Legs3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs41",
                    "EffectName"=>	"$Legs42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs43",
                            "value"=>	$Legs4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs51",
                    "EffectName"=>	"$Legs52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs53",
                            "value"=>	$Legs5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs61",
                    "EffectName"=>	"$Legs62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs63",
                            "value"=>	$Legs6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs71",
                    "EffectName"=>	"$Legs72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs73",
                            "value"=>	$Legs7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs81",
                    "EffectName"=>	"$Legs82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs83",
                            "value"=>	$Legs8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs91",
                    "EffectName"=>	"$Legs92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs93",
                            "value"=>	$Legs9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs101",
                    "EffectName"=>	"$Legs102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs103",
                            "value"=>	$Legs10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs111",
                    "EffectName"=>	"$Legs112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs113",
                            "value"=>	$Legs11val1
                        ],
                        [
                            "semantic"=>	"$Legs114",
                            "value"=>	$Legs11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs121",
                    "EffectName"=>	"$Legs122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs123",
                            "value"=>	$Legs12val1
                        ],
                        [
                            "semantic"=>	"$Legs124",
                            "value"=>	$Legs12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Legs131",
                    "EffectName"=>	"$Legs132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Legs133",
                            "value"=>	$Legs13val1
                        ],
                        [
                            "semantic"=>	"$Legs134",
                            "value"=>	$Legs13val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	17,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Foot Armor",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Rogue_Boots_Tier1",
            "Health" => $BootsAffix1val,
            "Armor" => $BootsAffix2val,
            "Resistance" => $BootsAffix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Boots11,
                    "EffectName"=> $Boots12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Boots13,
                            "value" => $Boots1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Boots21,
                    "EffectName"=> $Boots22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Boots23,
                            "value" => $Boots2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots31",
                    "EffectName"=>	"$Boots32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots33",
                            "value"=>	$Boots3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots41",
                    "EffectName"=>	"$Boots42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots43",
                            "value"=>	$Boots4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots51",
                    "EffectName"=>	"$Boots52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots53",
                            "value"=>	$Boots5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots61",
                    "EffectName"=>	"$Boots62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots63",
                            "value"=>	$Boots6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots71",
                    "EffectName"=>	"$Boots72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots73",
                            "value"=>	$Boots7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots81",
                    "EffectName"=>	"$Boots82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots83",
                            "value"=>	$Boots8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots91",
                    "EffectName"=>	"$Boots92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots93",
                            "value"=>	$Boots9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots101",
                    "EffectName"=>	"$Boots102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots103",
                            "value"=>	$Boots10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots111",
                    "EffectName"=>	"$Boots112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots113",
                            "value"=>	$Boots11val1
                        ],
                        [
                            "semantic"=>	"$Boots114",
                            "value"=>	$Boots11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots121",
                    "EffectName"=>	"$Boots122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots123",
                            "value"=>	$Boots12val1
                        ],
                        [
                            "semantic"=>	"$Boots124",
                            "value"=>	$Boots12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Boots131",
                    "EffectName"=>	"$Boots132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Boots133",
                            "value"=>	$Boots13val1
                        ],
                        [
                            "semantic"=>	"$Boots134",
                            "value"=>	$Boots13val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	5,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Shoulder",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Rogue_Pauldron_Tier1",
            "Health" => $Shoulder1Affix1val,
            "Armor" => $Shoulder1Affix2val,
            "Resistance" => $Shoulder1Affix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Shoulder111,
                    "EffectName"=> $Shoulder112,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Shoulder113,
                            "value" => $Shoulder11val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Shoulder121,
                    "EffectName"=> $Shoulder122,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Shoulder123,
                            "value" => $Shoulder12val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder131",
                    "EffectName"=>	"$Shoulder132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder133",
                            "value"=>	$Shoulder13val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder141",
                    "EffectName"=>	"$Shoulder142",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder143",
                            "value"=>	$Shoulder14val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder151",
                    "EffectName"=>	"$Shoulder152",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder153",
                            "value"=>	$Shoulder15val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder161",
                    "EffectName"=>	"$Shoulder162",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder163",
                            "value"=>	$Shoulder16val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder171",
                    "EffectName"=>	"$Shoulder172",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder173",
                            "value"=>	$Shoulder17val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder181",
                    "EffectName"=>	"$Shoulder182",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder183",
                            "value"=>	$Shoulder18val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder191",
                    "EffectName"=>	"$Shoulder192",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder193",
                            "value"=>	$Shoulder19val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder1101",
                    "EffectName"=>	"$Shoulder1102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder1103",
                            "value"=>	$Shoulder110val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder1111",
                    "EffectName"=>	"$Shoulder1112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder1113",
                            "value"=>	$Shoulder111val1
                        ],
                        [
                            "semantic"=>	"$Shoulder1114",
                            "value"=>	$Shoulder111val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder1121",
                    "EffectName"=>	"$Shoulder1122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder1123",
                            "value"=>	$Shoulder112val1
                        ],
                        [
                            "semantic"=>	"$Shoulder1124",
                            "value"=>	$Shoulder112val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder1131",
                    "EffectName"=>	"$Shoulder1132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder1133",
                            "value"=>	$Shoulder113val1
                        ],
                        [
                            "semantic"=>	"$Shoulder1134",
                            "value"=>	$Shoulder113val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	6,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Shoulder",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Rogue_Pauldron_Tier1",
            "Health" => $Shoulder2Affix1val,
            "Armor" => $Shoulder2Affix2val,
            "Resistance" => $Shoulder2Affix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Shoulder211,
                    "EffectName"=> $Shoulder212,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Shoulder213,
                            "value" => $Shoulder21val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Shoulder221,
                    "EffectName"=> $Shoulder222,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Shoulder223,
                            "value" => $Shoulder22val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder231",
                    "EffectName"=>	"$Shoulder232",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder233",
                            "value"=>	$Shoulder23val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder241",
                    "EffectName"=>	"$Shoulder242",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder243",
                            "value"=>	$Shoulder24val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder251",
                    "EffectName"=>	"$Shoulder252",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder253",
                            "value"=>	$Shoulder25val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder261",
                    "EffectName"=>	"$Shoulder262",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder263",
                            "value"=>	$Shoulder26val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder271",
                    "EffectName"=>	"$Shoulder272",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder273",
                            "value"=>	$Shoulder27val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder281",
                    "EffectName"=>	"$Shoulder282",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder283",
                            "value"=>	$Shoulder28val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder291",
                    "EffectName"=>	"$Shoulder292",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder293",
                            "value"=>	$Shoulder29val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder2101",
                    "EffectName"=>	"$Shoulder2102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder2103",
                            "value"=>	$Shoulder210val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder2111",
                    "EffectName"=>	"$Shoulder2112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder2113",
                            "value"=>	$Shoulder211val1
                        ],
                        [
                            "semantic"=>	"$Shoulder2114",
                            "value"=>	$Shoulder211val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder2121",
                    "EffectName"=>	"$Shoulder2122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder2123",
                            "value"=>	$Shoulder212val1
                        ],
                        [
                            "semantic"=>	"$Shoulder2124",
                            "value"=>	$Shoulder212val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shoulder2131",
                    "EffectName"=>	"$Shoulder2132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shoulder2133",
                            "value"=>	$Shoulder213val1
                        ],
                        [
                            "semantic"=>	"$Shoulder2134",
                            "value"=>	$Shoulder213val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	9,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Arm Armor",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Rogue_Glove_Tier1",
            "Health" => $Glove1Affix1val,
            "Armor" => $Glove1Affix2val,
            "Resistance" => $Glove1Affix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Glove111,
                    "EffectName"=> $Glove112,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Glove113,
                            "value" => $Glove11val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Glove121,
                    "EffectName"=> $Glove122,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Glove123,
                            "value" => $Glove12val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove131",
                    "EffectName"=>	"$Glove132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove133",
                            "value"=>	$Glove13val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove141",
                    "EffectName"=>	"$Glove142",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove143",
                            "value"=>	$Glove14val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove151",
                    "EffectName"=>	"$Glove152",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove153",
                            "value"=>	$Glove15val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove161",
                    "EffectName"=>	"$Glove162",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove163",
                            "value"=>	$Glove16val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove171",
                    "EffectName"=>	"$Glove172",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove173",
                            "value"=>	$Glove17val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove181",
                    "EffectName"=>	"$Glove182",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove183",
                            "value"=>	$Glove18val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove191",
                    "EffectName"=>	"$Glove192",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove193",
                            "value"=>	$Glove19val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove1101",
                    "EffectName"=>	"$Glove1102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove1103",
                            "value"=>	$Glove110val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove1111",
                    "EffectName"=>	"$Glove1112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove1113",
                            "value"=>	$Glove111val1
                        ],
                        [
                            "semantic"=>	"$Glove1114",
                            "value"=>	$Glove111val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove1121",
                    "EffectName"=>	"$Glove1122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove1123",
                            "value"=>	$Glove112val1
                        ],
                        [
                            "semantic"=>	"$Glove1124",
                            "value"=>	$Glove112val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove1131",
                    "EffectName"=>	"$Glove1132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove1133",
                            "value"=>	$Glove113val1
                        ],
                        [
                            "semantic"=>	"$Glove1134",
                            "value"=>	$Glove113val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	10,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Arm Armor",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Rogue_Glove_Tier1",
            "Health" => $Glove2Affix1val,
            "Armor" => $Glove2Affix2val,
            "Resistance" => $Glove2Affix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Glove211,
                    "EffectName"=> $Glove212,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Glove213,
                            "value" => $Glove21val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Glove221,
                    "EffectName"=> $Glove222,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Glove223,
                            "value" => $Glove22val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove231",
                    "EffectName"=>	"$Glove232",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove233",
                            "value"=>	$Glove23val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove241",
                    "EffectName"=>	"$Glove242",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove243",
                            "value"=>	$Glove24val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove251",
                    "EffectName"=>	"$Glove252",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove253",
                            "value"=>	$Glove25val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove261",
                    "EffectName"=>	"$Glove262",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove263",
                            "value"=>	$Glove26val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove271",
                    "EffectName"=>	"$Glove272",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove273",
                            "value"=>	$Glove27val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove281",
                    "EffectName"=>	"$Glove282",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove283",
                            "value"=>	$Glove28val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove291",
                    "EffectName"=>	"$Glove292",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove293",
                            "value"=>	$Glove29val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove2101",
                    "EffectName"=>	"$Glove2102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove2103",
                            "value"=>	$Glove210val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove2111",
                    "EffectName"=>	"$Glove2112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove2113",
                            "value"=>	$Glove211val1
                        ],
                        [
                            "semantic"=>	"$Glove2114",
                            "value"=>	$Glove211val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove2121",
                    "EffectName"=>	"$Glove2122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove2123",
                            "value"=>	$Glove212val1
                        ],
                        [
                            "semantic"=>	"$Glove2124",
                            "value"=>	$Glove212val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Glove2131",
                    "EffectName"=>	"$Glove2132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Glove2133",
                            "value"=>	$Glove213val1
                        ],
                        [
                            "semantic"=>	"$Glove2134",
                            "value"=>	$Glove213val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	21,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Ring",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Steel_Ring"
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Ring111,
                    "EffectName"=> $Ring112,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Ring113,
                            "value" => $Ring11val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Ring121,
                    "EffectName"=> $Ring122,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Ring123,
                            "value" => $Ring12val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring131",
                    "EffectName"=>	"$Ring132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring133",
                            "value"=>	$Ring13val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring141",
                    "EffectName"=>	"$Ring142",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring143",
                            "value"=>	$Ring14val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring151",
                    "EffectName"=>	"$Ring152",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring153",
                            "value"=>	$Ring15val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring161",
                    "EffectName"=>	"$Ring162",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring163",
                            "value"=>	$Ring16val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring171",
                    "EffectName"=>	"$Ring172",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring173",
                            "value"=>	$Ring17val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring181",
                    "EffectName"=>	"$Ring182",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring183",
                            "value"=>	$Ring18val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring191",
                    "EffectName"=>	"$Ring192",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring193",
                            "value"=>	$Ring19val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring1101",
                    "EffectName"=>	"$Ring1102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring1103",
                            "value"=>	$Ring110val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring1111",
                    "EffectName"=>	"$Ring1112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring1113",
                            "value"=>	$Ring111val1
                        ],
                        [
                            "semantic"=>	"$Ring1114",
                            "value"=>	$Ring111val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring1121",
                    "EffectName"=>	"$Ring1122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring1123",
                            "value"=>	$Ring112val1
                        ],
                        [
                            "semantic"=>	"$Ring1124",
                            "value"=>	$Ring112val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring1131",
                    "EffectName"=>	"$Ring1132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring1133",
                            "value"=>	$Ring113val1
                        ],
                        [
                            "semantic"=>	"$Ring1134",
                            "value"=>	$Ring113val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	22,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Ring",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Steel_Ring"
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Ring211,
                    "EffectName"=> $Ring212,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Ring213,
                            "value" => $Ring21val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Ring221,
                    "EffectName"=> $Ring222,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Ring223,
                            "value" => $Ring22val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring231",
                    "EffectName"=>	"$Ring232",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring233",
                            "value"=>	$Ring23val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring241",
                    "EffectName"=>	"$Ring242",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring243",
                            "value"=>	$Ring24val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring251",
                    "EffectName"=>	"$Ring252",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring253",
                            "value"=>	$Ring25val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring261",
                    "EffectName"=>	"$Ring262",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring263",
                            "value"=>	$Ring26val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring271",
                    "EffectName"=>	"$Ring272",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring273",
                            "value"=>	$Ring27val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring281",
                    "EffectName"=>	"$Ring282",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring283",
                            "value"=>	$Ring28val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring291",
                    "EffectName"=>	"$Ring292",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring293",
                            "value"=>	$Ring29val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring2101",
                    "EffectName"=>	"$Ring2102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring2103",
                            "value"=>	$Ring210val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring2111",
                    "EffectName"=>	"$Ring2112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring2113",
                            "value"=>	$Ring211val1
                        ],
                        [
                            "semantic"=>	"$Ring2114",
                            "value"=>	$Ring211val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring2121",
                    "EffectName"=>	"$Ring2122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring2123",
                            "value"=>	$Ring212val1
                        ],
                        [
                            "semantic"=>	"$Ring2124",
                            "value"=>	$Ring212val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Ring2131",
                    "EffectName"=>	"$Ring2132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Ring2133",
                            "value"=>	$Ring213val1
                        ],
                        [
                            "semantic"=>	"$Ring2134",
                            "value"=>	$Ring213val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	19,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Belt",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Alchemist_Sash"
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Belt11,
                    "EffectName"=> $Belt12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Belt13,
                            "value" => $Belt1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Belt21,
                    "EffectName"=> $Belt22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Belt23,
                            "value" => $Belt2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt31",
                    "EffectName"=>	"$Belt32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt33",
                            "value"=>	$Belt3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt41",
                    "EffectName"=>	"$Belt42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt43",
                            "value"=>	$Belt4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt51",
                    "EffectName"=>	"$Belt52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt53",
                            "value"=>	$Belt5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt61",
                    "EffectName"=>	"$Belt62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt63",
                            "value"=>	$Belt6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt71",
                    "EffectName"=>	"$Belt72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt73",
                            "value"=>	$Belt7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt81",
                    "EffectName"=>	"$Belt82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt83",
                            "value"=>	$Belt8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt91",
                    "EffectName"=>	"$Belt92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt93",
                            "value"=>	$Belt9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt101",
                    "EffectName"=>	"$Belt102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt103",
                            "value"=>	$Belt10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt111",
                    "EffectName"=>	"$Belt112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt113",
                            "value"=>	$Belt11val1
                        ],
                        [
                            "semantic"=>	"$Belt114",
                            "value"=>	$Belt11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt121",
                    "EffectName"=>	"$Belt122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt123",
                            "value"=>	$Belt12val1
                        ],
                        [
                            "semantic"=>	"$Belt124",
                            "value"=>	$Belt12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Belt131",
                    "EffectName"=>	"$Belt132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Belt133",
                            "value"=>	$Belt13val1
                        ],
                        [
                            "semantic"=>	"$Belt134",
                            "value"=>	$Belt13val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "BodyPart"=>	14,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	2,
        "ItemType"=>	"Amulet",
        "Value"=>	"100",
        "Level"=>	10,
        "Armor"=>	[
            "Name"=>	"Omnistar_Amulet"

        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Amulet11,
                    "EffectName"=> $Amulet12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Amulet13,
                            "value" => $Amulet1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Amulet21,
                    "EffectName"=> $Amulet22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Amulet23,
                            "value" => $Amulet2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet31",
                    "EffectName"=>	"$Amulet32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet33",
                            "value"=>	$Amulet3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet41",
                    "EffectName"=>	"$Amulet42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet43",
                            "value"=>	$Amulet4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet51",
                    "EffectName"=>	"$Amulet52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet53",
                            "value"=>	$Amulet5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet61",
                    "EffectName"=>	"$Amulet62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet63",
                            "value"=>	$Amulet6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet71",
                    "EffectName"=>	"$Amulet72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet73",
                            "value"=>	$Amulet7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet81",
                    "EffectName"=>	"$Amulet82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet83",
                            "value"=>	$Amulet8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet91",
                    "EffectName"=>	"$Amulet92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet93",
                            "value"=>	$Amulet9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet101",
                    "EffectName"=>	"$Amulet102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet103",
                            "value"=>	$Amulet10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet111",
                    "EffectName"=>	"$Amulet112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet113",
                            "value"=>	$Amulet11val1
                        ],
                        [
                            "semantic"=>	"$Amulet114",
                            "value"=>	$Amulet11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet121",
                    "EffectName"=>	"$Amulet122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet123",
                            "value"=>	$Amulet12val1
                        ],
                        [
                            "semantic"=>	"$Amulet124",
                            "value"=>	$Amulet12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Amulet131",
                    "EffectName"=>	"$Amulet132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Amulet133",
                            "value"=>	$Amulet13val1
                        ],
                        [
                            "semantic"=>	"$Amulet134",
                            "value"=>	$Amulet13val2
                        ]
                    ]
                ]
                
            ]
        ]
    ]
    
];

$data['InventoryGrid'] = [
    (object) [
        "InventoryX"=> 0,
        "InventoryY"=> 0,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	3,
        "ItemType"=>	$MH11,
        "Value"=>	"100",
        "Level"=>	10,
        "Weapon"=>	[
            "Name"=>	$MH12,
            "DamageMin" => $MainHandAffix1val,
            "DamageMax" => $MainHandAffix2val,
            "ResourceGeneration" => $MainHandAffix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $MainHand11,
                    "EffectName"=> $MainHand12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $MainHand13,
                            "value" => $MainHand1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $MainHand21,
                    "EffectName"=> $MainHand22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $MainHand23,
                            "value" => $MainHand2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand31",
                    "EffectName"=>	"$MainHand32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand33",
                            "value"=>	$MainHand3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand41",
                    "EffectName"=>	"$MainHand42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand43",
                            "value"=>	$MainHand4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand51",
                    "EffectName"=>	"$MainHand52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand53",
                            "value"=>	$MainHand5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand61",
                    "EffectName"=>	"$MainHand62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand63",
                            "value"=>	$MainHand6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand71",
                    "EffectName"=>	"$MainHand72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand73",
                            "value"=>	$MainHand7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand81",
                    "EffectName"=>	"$MainHand82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand83",
                            "value"=>	$MainHand8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand91",
                    "EffectName"=>	"$MainHand92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand93",
                            "value"=>	$MainHand9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand101",
                    "EffectName"=>	"$MainHand102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand103",
                            "value"=>	$MainHand10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand111",
                    "EffectName"=>	"$MainHand112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand113",
                            "value"=>	$MainHand11val1
                        ],
                        [
                            "semantic"=>	"$MainHand114",
                            "value"=>	$MainHand11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand121",
                    "EffectName"=>	"$MainHand122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand123",
                            "value"=>	$MainHand12val1
                        ],
                        [
                            "semantic"=>	"$MainHand124",
                            "value"=>	$MainHand12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$MainHand131",
                    "EffectName"=>	"$MainHand132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$MainHand133",
                            "value"=>	$MainHand13val1
                        ],
                        [
                            "semantic"=>	"$MainHand134",
                            "value"=>	$MainHand13val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "InventoryX"=> 2,
        "InventoryY"=> 0,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	3,
        "ItemType"=>	$OH11,
        "Value"=>	"100",
        "Level"=>	10,
        "Weapon"=>	[
            "Name"=>	$OH12,
            "DamageMin" => $OffHandAffix1val,
            "DamageMax" => $OffHandAffix2val,
            "ResourceGeneration" => $OffHandAffix3val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $OffHand11,
                    "EffectName"=> $OffHand12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $OffHand13,
                            "value" => $OffHand1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $OffHand21,
                    "EffectName"=> $OffHand22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $OffHand23,
                            "value" => $OffHand2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand31",
                    "EffectName"=>	"$OffHand32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand33",
                            "value"=>	$OffHand3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand41",
                    "EffectName"=>	"$OffHand42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand43",
                            "value"=>	$OffHand4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand51",
                    "EffectName"=>	"$OffHand52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand53",
                            "value"=>	$OffHand5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand61",
                    "EffectName"=>	"$OffHand62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand63",
                            "value"=>	$OffHand6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand71",
                    "EffectName"=>	"$OffHand72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand73",
                            "value"=>	$OffHand7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand81",
                    "EffectName"=>	"$OffHand82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand83",
                            "value"=>	$OffHand8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand91",
                    "EffectName"=>	"$OffHand92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand93",
                            "value"=>	$OffHand9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand101",
                    "EffectName"=>	"$OffHand102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand103",
                            "value"=>	$OffHand10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand111",
                    "EffectName"=>	"$OffHand112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand113",
                            "value"=>	$OffHand11val1
                        ],
                        [
                            "semantic"=>	"$OffHand114",
                            "value"=>	$OffHand11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand121",
                    "EffectName"=>	"$OffHand122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand123",
                            "value"=>	$OffHand12val1
                        ],
                        [
                            "semantic"=>	"$OffHand124",
                            "value"=>	$OffHand12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$OffHand131",
                    "EffectName"=>	"$OffHand132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$OffHand133",
                            "value"=>	$OffHand13val1
                        ],
                        [
                            "semantic"=>	"$OffHand134",
                            "value"=>	$OffHand13val2
                        ]
                    ]
                ]
                
            ]
        ]
    ],
    (object) [
        "InventoryX"=> 4,
        "InventoryY"=> 0,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	3,
        "ItemType"=>	"Shield",
        "Value"=>	"100",
        "Level"=>	10,
        "Weapon"=>	[
            "Name"=>	"1h_shield_tier3",
            "DamageMin" => $ShieldAffix1val,
            "DamageMax" => $ShieldAffix2val,
            "ShieldResistance" => $ShieldAffix3val,
	    "ShieldBlockChance" => $ShieldAffix4val,
	    "ShieldBlockEfficiency" => $ShieldAffix5val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Shield11,
                    "EffectName"=> $Shield12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Shield13,
                            "value" => $Shield1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Shield21,
                    "EffectName"=> $Shield22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Shield23,
                            "value" => $Shield2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield31",
                    "EffectName"=>	"$Shield32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield33",
                            "value"=>	$Shield3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield41",
                    "EffectName"=>	"$Shield42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield43",
                            "value"=>	$Shield4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield51",
                    "EffectName"=>	"$Shield52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield53",
                            "value"=>	$Shield5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield61",
                    "EffectName"=>	"$Shield62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield63",
                            "value"=>	$Shield6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield71",
                    "EffectName"=>	"$Shield72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield73",
                            "value"=>	$Shield7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield81",
                    "EffectName"=>	"$Shield82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield83",
                            "value"=>	$Shield8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield91",
                    "EffectName"=>	"$Shield92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield93",
                            "value"=>	$Shield9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield101",
                    "EffectName"=>	"$Shield102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield103",
                            "value"=>	$Shield10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield111",
                    "EffectName"=>	"$Shield112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield113",
                            "value"=>	$Shield11val1
                        ],
                        [
                            "semantic"=>	"$Shield114",
                            "value"=>	$Shield11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield121",
                    "EffectName"=>	"$Shield122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield123",
                            "value"=>	$Shield12val1
                        ],
                        [
                            "semantic"=>	"$Shield124",
                            "value"=>	$Shield12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Shield131",
                    "EffectName"=>	"$Shield132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Shield133",
                            "value"=>	$Shield13val1
                        ],
                        [
                            "semantic"=>	"$Shield134",
                            "value"=>	$Shield13val2
                        ]
                    ]
                ]
            
            ]
        ]
    ],
    (object) [
        "InventoryX"=> 6,
        "InventoryY"=> 0,
        "Rarity"=>	3,
        "Quality"=>	2,
        "Type"=>	3,
        "ItemType"=>	"Trinket",
        "Value"=>	"100",
        "Level"=>	10,
        "Weapon"=>	[
            "Name"=>	"1H_OffHand_Tier3",
            "DamageMin" => $CatalystAffix1val,
            "DamageMax" => $CatalystAffix2val
        ],
        "MagicEffects"=>	[
            "Default"=>	[],
            "RolledAffixes"=>	[
                [
                    "EffectId"=> $Catalyst11,
                    "EffectName"=> $Catalyst12,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Catalyst13,
                            "value" => $Catalyst1val
                        ]
                    ]
                ],
                [
                    "EffectId"=> $Catalyst21,
                    "EffectName"=> $Catalyst22,
                    "MaxStack"=> 1,
                    "Parameters"=>	[
                        [
                            "semantic" => $Catalyst23,
                            "value" => $Catalyst2val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst31",
                    "EffectName"=>	"$Catalyst32",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst33",
                            "value"=>	$Catalyst3val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst41",
                    "EffectName"=>	"$Catalyst42",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst43",
                            "value"=>	$Catalyst4val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst51",
                    "EffectName"=>	"$Catalyst52",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst53",
                            "value"=>	$Catalyst5val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst61",
                    "EffectName"=>	"$Catalyst62",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst63",
                            "value"=>	$Catalyst6val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst71",
                    "EffectName"=>	"$Catalyst72",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst73",
                            "value"=>	$Catalyst7val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst81",
                    "EffectName"=>	"$Catalyst82",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst83",
                            "value"=>	$Catalyst8val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst91",
                    "EffectName"=>	"$Catalyst92",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst93",
                            "value"=>	$Catalyst9val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst101",
                    "EffectName"=>	"$Catalyst102",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst103",
                            "value"=>	$Catalyst10val
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst111",
                    "EffectName"=>	"$Catalyst112",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst113",
                            "value"=>	$Catalyst11val1
                        ],
                        [
                            "semantic"=>	"$Catalyst114",
                            "value"=>	$Catalyst11val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst121",
                    "EffectName"=>	"$Catalyst122",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst123",
                            "value"=>	$Catalyst12val1
                        ],
                        [
                            "semantic"=>	"$Catalyst124",
                            "value"=>	$Catalyst12val2
                        ]
                    ]
                ],
                [
                    "EffectId"=>	"$Catalyst131",
                    "EffectName"=>	"$Catalyst132",
                    "MaxStack"=>	1,
                    "Parameters"=>	[
                        [
                            "semantic"=>	"$Catalyst133",
                            "value"=>	$Catalyst13val1
                        ],
                        [
                            "semantic"=>	"$Catalyst134",
                            "value"=>	$Catalyst13val2
                        ]
                    ]
                ]
                
            ]
        ]
    ]
];


$json = json_encode($data);

header('Content-disposition: attachment; filename='.$name.'.json');
header('Content-type: application/json');
   
echo $json;

?>